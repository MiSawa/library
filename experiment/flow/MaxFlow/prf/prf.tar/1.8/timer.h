#ifndef __TIMER_H__
#define __TIMER_H__

float timer(void);

#endif /*__TIMER_H__ */
