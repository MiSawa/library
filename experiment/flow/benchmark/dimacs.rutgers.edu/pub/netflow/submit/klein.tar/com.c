#include "concur.h"

extern char zz;
extern double idn;

void commodity::print()
    {
    dnode v;
    dedge e;
    edgeListElt *elep;

    cout << "Commodity #" << number << endl;
    cout << "Source = " << cf->G.inf(source) << "\tSink = " << cf->G.inf(sink) << endl;
    cout << "Sigma = " << SIGMA(this) << "\tWeight = " << weight << "\tMinflow = " << minflow << endl;
    dforall_nodes(v,flowG)
	{
	cout << "Node " << id(v) << ":\n   In = " << indeg(v) << endl;
	dforall_in_edges(e,v,flowG,elep)
	    {
	    cout << "\t" << flowG.inf(e) << "\n";
	    cout << "\t\t" << cf->G.inf(flowG.inf(e).Gedge);
	    }
	cout << "   Out = " << outdeg(v) << "\n";
	dforall_out_edges(e,v,flowG,elep)
	    {
	    cout << "\t" << flowG.inf(e) << "\n";
	    cout << "\t\t" << cf->G.inf(flowG.inf(e).Gedge);
	    }
	}
    }

void commodity::incflow(edge e, node t, double dflow, int debug)
    {
// Edge e is in G
// Node t is in G (sink of flow along edge)

    if (debug) here ("start");
    node       s=cf->G.opposite(t,e);
    dnode      u,v;
    dedge      ce=corr_edge(e,s);
    comedge    newedge; newedge.id = cf->G.inf(e).id;
    double     oldflow,newflow;

    idn += dflow*(cf->G.inf(e).id)/(cf->G.inf(t));
    if (ce!=0)
	{
	oldflow = flowG.inf(ce).flow;
	if (corr_node[s]!=flowG.source(ce))     // Flow going against edge direction
	     {
	     dflow = -dflow;
	     swap (s,t);
	     }
	cf->G.inf(e).incflow(-oldflow);   // Get rid of old flow in big graph
	flowG.inf(ce).flow += dflow;
	newflow = flowG.inf(ce).flow;

// If the flow is negative, reverse the edge,
// if the edge has practically no length, kill it.
	if (absol(flowG.inf(ce).flow) <= FLOWTOL)
	    {
	    if (debug) here ("e1");
	    u = flowG.source(ce);
	    v = flowG.target(ce);
	    flowG.del_edge(ce);
	    newflow = 0;
	    if ((flowG.indeg(u)==0) && (flowG.outdeg(u)==0)) 
		{
		if (debug) here ("e2");
		corr_node[flowG.inf(u)]=0;
		flowG.del_node(u);
		}
	    if ((flowG.indeg(v)==0) && (flowG.outdeg(v)==0))
		{
		if (debug) here ("e3");
		corr_node[flowG.inf(v)]=0;
		flowG.del_node(v);
		}
	    }
	else if (flowG.inf(ce).flow < 0)
	    {
	    if (debug) here ("e4");
	    newedge.Gedge = e;
	    newedge.flow = -flowG.inf(ce).flow;
	    flowG.new_edge(flowG.target(ce), flowG.source(ce), newedge);  // KILL temp
	    flowG.del_edge(ce);
	    newflow = flowG.inf(ce).flow;
	    }
	}
    else if (absol(dflow) > FLOWTOL)
	{
	if (debug) here ("e5");
	oldflow = 0;
	if (corr_node[s]==0) corr_node[s] = flowG.new_node(s);
	if (corr_node[t]==0) corr_node[t] = flowG.new_node(t);
	newedge.Gedge = e;
	newedge.flow  = absol(dflow);
	if (dflow<0) swap(s,t);
	flowG.new_edge(corr_node[s], corr_node[t], newedge);
	newflow = absol(dflow);
	}
    cf->G.inf(e).incflow(newflow);   // Add new flow to big graph
    }

commodity::commodity(cflow *_cf, node s, node t, double d, int n)
    : cf(_cf), longpath(cf->G), shortpath(cf->G),
      corr_node(cf->G,0), source(s), sink(t), demand(d), number(n), sigma(d),
      minflow(d), large_sigma_count(0), tally(0)
    {
    node v;
    edge e;
    double len;
// Find some inital flow

    len=cf->findShortPath(this,MINDIST,MAXDIST);
    shortpath.length (len);
    longpath = shortpath;
    longpath.length (len);
	// In the beginning, shortpath is the only path in
	// the flow graph, so it's also the longest
    for (shortpath.reset(v,e); !shortpath.end(); shortpath.next(v,e))
	{
	incflow(e,v,demand);
	}
    }

void commodity::reroute_flow (int n, int debug)
// Reroutes flow from 'longpath' to 'shortpath'
{
  node v;
  edge e;

/*
  cout << "S:Rerouting " << n << " units = " << n*SIGMA(this) 
    << " from " << &shortpath << " to " << &longpath << endl;
*/


    for (shortpath.reset(v,e); !shortpath.end(); shortpath.next(v,e))
	{
	if (debug)
	    {
	    here ("b5");
	    cout << v << "\t" << source << endl;
	    cout << cf->G.inf(v) << "\t" << cf->G.inf(source) << endl;
	    }
	incflow (e,v,n*SIGMA(this),debug); // Adds flow to short path
	}
    for (longpath.reset(v,e); !longpath.end(); longpath.next(v,e))
	{
	if (debug)
	    {
	    here ("Debug");
	    cout << "Source, sink = " << cf->G.inf(source);
	    cout << "\t" << cf->G.inf(sink) << endl;
	    cout << corr_node[source] << "\t" << v << endl;
	    cout << "Rerouting " << n*SIGMA(this) << endl;
	    }
	incflow (e,v,-n*SIGMA(this));  // Takes flow off long path
	if (debug) here ("b4");
	}
    if (debug) flowG.print();
    if (debug) here ("b6");
    }

/* This is shamelessly copied... */
void commodity::reroute_flow (double move_flow, int debug)
{
  node v;
  edge e;

/*
  cout << "Rerouting " << move_flow
    << " from " << &shortpath << " to " << &longpath << endl;
*/

//  cout << "Moving flow: " << move_flow << endl;
  for (shortpath.reset(v,e); !shortpath.end(); shortpath.next(v,e))
    incflow (e,v,move_flow,debug); // Adds flow to short path

  for (longpath.reset(v,e); !longpath.end(); longpath.next(v,e))  {
    if (debug)  {
      here ("Debug");
      cout << "Source, sink = " << cf->G.inf(source);
      cout << "\t" << cf->G.inf(sink) << endl;
      cout << corr_node[source] << "\t" << v << endl;
      cout << "Rerouting " << move_flow << endl;
    }
    incflow (e,v,-move_flow);  // Takes flow off long path
      if (debug) here ("b4");
  }
  if (debug) flowG.print();
  if (debug) here ("b6");
}


double commodity::update_weight()
    {
    longpath.recompute_length();
    shortpath.recompute_length();
    weight = SIGMA(this)*(longpath.length()-shortpath.length());
    if (weight < 0.0) weight = 0.0;
    return weight;
    }

dedge commodity::corr_edge(edge e, node v, int dir)
// Dir = 0 means check in edges only
// Dir = 1 means check in and out edges
// Dir = 2 means check out edges only
    {
    dedge e1;
    edgeListElt *elep;

    if (corr_node[v]==0) return 0;
    if (dir<2)
	dforall_in_edges(e1,corr_node[v],flowG,elep)
	    if (flowG.inf(e1).Gedge==e) return e1;
    if (dir>0)
	dforall_out_edges(e1,corr_node[v],flowG,elep)
	    if (flowG.inf(e1).Gedge==e) return e1;
    return 0;
    }
