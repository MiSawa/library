#include "heap.h"
#define INLINE

/* This used to be in heap.h */


/** MOVE **/

INLINE void NodeHeap::move(int from,int to)
{
    positionArray[G->inf(heapArray[from].elt)] = to;
    heapArray[to] = heapArray[from];
/*    heapArray[to].elt = heapArray[from].elt;*/
}

/** REMOVE **/

INLINE node NodeHeap::remove(int from)
{
node removedNode;
    
    removedNode = heapArray[from].elt;
    inQueueArray[G->inf(removedNode)] = NOTNOW;  
    removedArray[G->inf(removedNode)] = currentTime;
    return removedNode;
}



INLINE void NodeHeap::init()
{    numElemsIn = 0;
     currentTime++;
}



/** INSERT NODE **/

INLINE void NodeHeap::insertNode(node v,Dist dist)
{
    if (numElemsIn >= maxNumElems)
	cerr << "Attempted insertion in full Queue\n";
    heapArray[++numElemsIn].elt = v;
    heapArray[numElemsIn].dist = dist;

    /* array[0] not given value yet */

    positionArray[G->inf(v)] = numElemsIn;
    inQueueArray[G->inf(v)] = currentTime;
    upHeap(numElemsIn);
}

/** MIN DIST **/

INLINE Dist NodeHeap::minDist()
{ 
    return heapArray[ROOT].dist;
}

/** NOT EMPTY QUEUE **/
INLINE int NodeHeap::notEmptyP()
{
  return numElemsIn;
  }


/** REMOVE MIN **/ 
INLINE node NodeHeap::removeMin()
{
    node nodeRemoved;
    
    nodeRemoved = remove(ROOT);
    numElemsIn--;
    if (numElemsIn !=0){
        move(numElemsIn+1,ROOT);
        downHeap(ROOT);
    }
    return nodeRemoved;
}

INLINE void NodeHeap::removeNode(node nodeToRemove)
{
  int pos;

  pos=positionArray[G->inf(nodeToRemove)];
  remove(pos);
  numElemsIn--;
  if (numElemsIn != 0 && pos != numElemsIn+1){
    move(numElemsIn+1,pos);
    downHeap(pos);
  }
}

/** DECREASE KEY **/

INLINE void NodeHeap::decreaseKey(node theNode,Dist newKey)
{
  int  position;
    
    position = positionArray[G->inf(theNode)];
    heapArray[position].dist = newKey;
    upHeap(position);
}


/** DIST OF **/

INLINE Dist NodeHeap::distOf(node theNode)
{
    return heapArray[positionArray[G->inf(theNode)]].dist;
}


/** IN QUEUE **/
/** Returns true if given node is in priority queue **/

INLINE bool NodeHeap::inQueueP(node theNode)
{
    return (inQueueArray[G->inf(theNode)] == currentTime);
}

INLINE bool NodeHeap::removedFromP(node theNode)
{
    return (removedArray[G->inf(theNode)] == currentTime);
}


INLINE void NodeHeap::markAsRemoved(node theNode)
     {
       removedArray[G->inf(theNode)] = currentTime;
     }

/* End of that stuff.... */

void NodeHeap::print_inQ()
    {
    node v;
    cout << "Current time = " << currentTime << endl;
    cout << "Node\tArray value\n";
    forall_nodes(v,*G) cout << G->inf(v) << "\t" << inQueueArray[G->inf(v)] << endl;
    }

/*WARNING: array allocation assumes nodes numbered consecutively! */
NodeHeap::NodeHeap(cfgraph* CG)
    {
    node v;
    G = CG;
    int numNodes=G->number_of_nodes();
    heapArray = new HeapElt[numNodes+2];
    heapArray[SUBROOT].dist = DIST_MIN; 
/* flag to stop loop if valueChecking goes to top */
    positionArray = new int[numNodes+1];
    currentTime = 0;
    inQueueArray = new long[numNodes+1];
    removedArray = new long[numNodes+1];
    forall_nodes(v,*CG)
	{
	if (G->inf(v) > numNodes)
	    cerr << "Node index higher than number of nodes";
	inQueueArray[G->inf(v)] = NOTNOW;
	removedArray[G->inf(v)] = NOTNOW;
	}
    TEMP = numNodes+1;
    maxNumElems = numNodes;
    }

NodeHeap::~NodeHeap()
    {
    delete [] positionArray;
    delete [] inQueueArray;
    delete [] removedArray;
    delete [] heapArray;
    }

/* ------------ following are private subroutines ---------- */


/** DOWNHEAP (from node nodeNum) **/

void NodeHeap::downHeap(int position)
{
    int smallerChild;             /* index of arrayInfo nodeArray */
    Dist valueMoving;
    
    valueMoving = heapArray[position].dist;
    move(position,TEMP);
    
    while (position <= numElemsIn/2){  /* while nodeNum internal node of tree */
	
	smallerChild = LEFTCHILD(position);
	/* set left child's index as node w/larger value to start */
	
	if (smallerChild < numElemsIn && 
	    heapArray[smallerChild].dist > heapArray[smallerChild + 1].dist)
	    smallerChild++;                                    
	
	/* if right child's value is larger take index */
	
	
	if (valueMoving <= heapArray[smallerChild].dist)
	    break;                                                           
	/* check if valueMoving is in correct location */
	
	move(smallerChild, position);
	position = smallerChild;
    }
    move(TEMP,position);
}


/** UP_HEAP **/

void NodeHeap::upHeap(int position)
{
    Dist valueChecking;         /* distance at passed node */
    
    valueChecking = heapArray[position].dist;
    move(position,TEMP);
    
    while (heapArray[PARENT(position)].dist > valueChecking){
	move(PARENT(position),position);
	position = PARENT(position);
    }
    
    move(TEMP,position);
}

