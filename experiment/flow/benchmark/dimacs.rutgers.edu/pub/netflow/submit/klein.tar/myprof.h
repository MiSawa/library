/*
#define MARK(L) {\
		asm("	.reserve	.L., 4, \"data\", 4");\
		asm("M.L:");\
		asm("	sethi	%hi(.L.), %o0");\
		asm("	call	mcount");\
		asm("	or	%o0, %lo(.L.), %o0");\
		}
*/

#define MARK(L)



