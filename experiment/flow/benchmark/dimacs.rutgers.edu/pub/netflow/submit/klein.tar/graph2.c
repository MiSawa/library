#include <iostream.h>
#include <stdlib.h>
#include "graph2.h"

int DIR::del_from_adj_list (edgeListElt **plist, dedge e)
    {
    edgeListElt *last,*p=*plist;

    if (*plist==0) return 0;  // Not found
    if ((*plist)->edge==e)
        {
        *plist = (*plist)->next_edge;
        delete p;
        return 1;
        }
    else
        {
        while (p!=0 && p->edge!=e)
            {
            last = p;
            p = p->next_edge;
            }
        if (p==0) return 0;
        last->next_edge = p->next_edge;
        delete p;
        return 1;
        }
    }

void DIR::del_edge (dedge e)
    {
    int n1 = del_from_adj_list (&(e->ep1->in_adj_list),e) +
             del_from_adj_list (&(e->ep1->out_adj_list),e);
    int n2 = del_from_adj_list (&(e->ep2->in_adj_list),e) +
             del_from_adj_list (&(e->ep2->out_adj_list),e);
    if (n1!=1 || n2!=1)
        {
	cout << "Edge " << e << " found " << n1 <<
                " times in the adjacency list for " << e->ep1 << " and " <<
             n2 << " times in the list for " << e->ep2 << 
	     ".\nIt should occur exaclty once in each.\n";
	exit(1);
        }
    if (e->dir==1)
        {
        e->ep1->outdeg--;
        e->ep2->indeg--;
        }
    else
        {
        e->ep1->indeg--;
        e->ep2->outdeg--;
        }
    delete e;
    edges--;
    }

dnode DIR::new_node (ent info)
    {
    dnode p = new DIRnode;

    p->inf = info;
    p->indeg = p->outdeg = 0;
    p->in_adj_list = p->out_adj_list = 0;
    p->next_node = node_list;
    node_list = p;
    nodes++;
    return p;
    }  

void DIR::del_node (dnode v)
    {
    dnode last,p = node_list;

    if (v->indeg!=0 || v->outdeg!=0)
	cout << "Node " << v << " has indeg " << v->indeg << " and outdeg " << v->outdeg << "." << endl;
    if (node_list==0)
        {
        cout << "Node " << v << " can not be deleted.\nThere are no nodes in the graph.\n";
	exit(1);
        }
    if (v==node_list)
        {
        node_list = node_list->next_node;
        delete p;
        nodes--;
        }
    else
        {
        while (p!=0 && p!=v)
            {
            last = p;
            p = p->next_node;
            } 
        if (p==0)
            {
            cout << "Node " << v << " does not exist.\n";
            exit(1);
            }
        last->next_node = p->next_node;
        delete p;
        nodes--; 
	}
    }

dedge DIR::new_edge (dnode s, dnode t, ent info)
    {
    dedge e = new DIRedge;
    e->inf = info;
    e->ep1 = s;
    e->ep2 = t;
    e->dir = 1;

    edgeListElt* elep = new edgeListElt;
    elep->edge = e;
    elep->next_edge = s->out_adj_list;
    s->out_adj_list = elep;
    s->outdeg++;

    elep = new edgeListElt;
    elep->edge = e;
    elep->next_edge = t->in_adj_list;
    t->in_adj_list = elep;
    t->indeg++;
   
    edges++;
    return e;
    }  

void DIR::assign (dnode v, ent info)
    {
    dnode p;
    for (p=node_list; p!=0 && p!=v; p=p->next_node);
    if (p==0)
        {
	cout << "Node " << v << " does not exist.\nCan't assign " << info << " to it.\n";
	exit(1);
        }
    p->inf = info;
    }  

void DIR::assign (dedge e, ent info)
    {
    edgeListElt *p;

    p = e->dir ? e->ep1->out_adj_list : e->ep1->in_adj_list;
    for (;p!=0 && p->edge!=e; p=p->next_edge);
    if (p==0)
        {
        cout << "Edge " << e << " does not exist.\nCan't assign " << info << " to it.\n";
        exit(1);
        }
    p->edge->inf = info;
    }

void DIR::clear()
    {
    dnode u,v;
    edgeListElt *p1,*p2;

    dforall_nodes(v,*this)
        {
        p1 = p2 = v->out_adj_list;
        while (p2!=0)
            {
            p1 = p1->next_edge;
            delete p2->edge;
            delete p2;
            p2 = p1;
            }
        p1 = p2 = v->in_adj_list;
        while (p2!=0)
            {
            p1 = p1->next_edge;
            delete p2;
            p2 = p1;
            }
        }
    v = u = this->node_list;
    while (v!=0)
        {
        u = u->next_node;
        delete v;
        v = u;
        }
    nodes = edges = 0;
    }  
