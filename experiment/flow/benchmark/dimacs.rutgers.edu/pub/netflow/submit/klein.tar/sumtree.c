#include "concur.h"
#include "sumtree.h"

sumtree::sumtree(int sz) : size(sz)
    {
    arr = new sumtreeNode[size];
    numElts = 0;
    }

void sumtree::scale(double k)
    {
    for (int i=numElts-1; i>=0; i--)
	{
	arr[i].value *= k;
	arr[i].sum = arr[i].value + sum(2*i+1) + sum(2*i+2);
	}
    }

stkey sumtree::add(const InfoClass& elt, double value)
/* Returns key of the added elt.  This key must be supplied to some other functions. */
    {
    if (numElts >= size)
	{
	sumtreeNode *oldArr = arr;
	size *= 2;
	arr = new sumtreeNode[size];
	for (int i=0; i<numElts; i++) arr[i] = oldArr[i];
	delete oldArr;
	}
    arr[numElts].info = elt;
    change(numElts,value);
    return (numElts++);
    }

void sumtree::change(stkey key, double value)
    {
    arr[key].value = value;
    for (; key!=-1; key = (key-2+key%2) / 2)
	arr[key].sum = sum(2*key+1)+sum(2*key+2)+arr[key].value;
/*
    for (key=0; key<numElts; key++) if (sum(key)-sum(2*key+1)-sum(2*key+2) < 0)
	{
	cerr << "Inc = " << inc << endl;
	cerr << "Key = " << key << endl;
	cerr << *this << endl;
	}
*/
    }

InfoClass sumtree::select(double value, stkey &key) const
/* Returns an elt and its key of the sumtree based on 'value' 0..1 */
    {
    bool   done=FALSE;
    stkey  n=0;

    value *= arr[0].sum;
    if (value<0)
	{
	cerr << "Value = " << value << endl;
	cerr << *this << endl;
	}
    while (!done)
	{
	if (n<0) cerr << "reps = " << reps << "\nerror: n = " << n << endl;
	if (value<sum(2*n+1))
	    n=2*n+1;
	else if (value<sum(2*n+1)+sum(2*n+2))
	    {
	    n=2*n+2;
	    value -= sum(n-1);
	    }
	else
	    done = TRUE;
	}
    key = n;
    return arr[n].info;
    }

InfoClass sumtree::blindSelect(double value, stkey &key) const
/* Returns an elt and its key of the sumtree based on 'value' 0..1 
    Ignores weights; selects uniformly among elements */
    { 
    key = (int) (value*(float) numElts);
    return arr[key].info;
    }

ostream& operator << (ostream& os, const sumtree& st)
    {
    int i;
    for (i=0; i<st.numElts; i++)
	os << i << ":  " << st.sum(i) << "  "
	   << st.sum(i)-st.sum(2*i+1)-st.sum(2*i+2) << "  "
	   << st.arr[i].value << endl;
    return os;
    }  
