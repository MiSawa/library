#include "path.h"

pathListElt* path::Reset()
    { pathListElt *x; L.init_iterator(); L.next_element(x); return x; }
pathListElt* path::Current() const
    {
    pathListElt *x;
    if(!L.current_element(x))
        {
        cout << "No current node/edge in path.  Iterator not defined.\n";
        exit(1);
        }
    return x;
    }  
pathListElt *path::Next()
    { pathListElt *x; L.next_element(x); return x; }
void path::reset(node& v) { v=Reset()->v; }
void path::reset(edge& e) { e=Reset()->e; }
void path::reset(node& v, edge& e)
    { pathListElt *x=Reset(); v=x->v; e=x->e; }
void path::next(node& v) { v=Next()->v; }
void path::next(edge& e) { e=Next()->e; }
void path::next(node& v, edge& e)
    { pathListElt *x=Next(); v=x->v; e=x->e; }
node path::current_node() const { return Current()->v; }
edge path::current_edge() const { return Current()->e; }

void path::truncate()
    {
    L.pop();
    }

void path::pretruncate()
    {
    L.Pop();
    L.tail()->e = 0;
    }

path::path(cfgraph &_G)
    {
    G=&_G;
    _len=0;
    }

path::path(cfgraph &_G, node s)
    {
    G=&_G;
    _len=0;
    add_first_node(s);
    }

node path::append(edge e)
// And edge to sink endpoint
    {
    if ((G->target(e) != sink()) && (G->source(e) != sink()))
        {
        cout << "Edge "; G->Print(e,cout); cout <<" can not be appended to path.\n";
        cout << "Target: "; G->Print(G->target(e),cout);
        cout << "\nSource: "; G->Print(G->source(e),cout);
        cout << "\nPath:\n" << *this << endl;
        exit(1);
        }
    pathListElt *ple = new pathListElt;
    ple->v = (G->target(e) == sink()) ? G->source(e) : G->target(e);
    ple->e = e;
    L.push(ple);
    return sink();
    }

node path::prepend(edge e)
// Add edge to source endpoint
    {    
    if ((G->target(e) != source()) && (G->source(e) != source()))
        {
        cout << "Edge " << e;
        G->Print(e,cout); 
        cout <<"\ncan not be prepended to path.\n";
        cout << "Target: "; G->Print(G->target(e),cout);
        cout << "\nSource: "; G->Print(G->source(e),cout);
        cout << "\nPath:\n" << *this << endl;
        exit(1);
        }
    L.tail()->e = e;
    pathListElt *ple = new pathListElt;
    ple->v = (G->target(e) == source()) ? G->source(e) : G->target(e);
    ple->e = 0;
    L.append(ple);
    return source();
    }

void path::clear()
    {
    pathListElt *ple;
    forall(ple,L) delete ple;
    L.clear();
    _len = 0;
    }

void path::add_first_node(node v)
    {
    if (exists())
        {
        cout << "Can not add node "; G->Print(v,cout);
        cout << "as first node.\nA first node has already been added." << endl;
        exit(1);
        }
    pathListElt *ple = new pathListElt;
    ple->v = v;
    ple->e = 0;
    L.push(ple);
    }

double path::recompute_length()
    {
    edge e;
    _len = 0;
    for (reset(e); !end(); next(e)) _len += G->inf(e).len();
    return _len;
    }

path& path::operator=(path &p)
    {
    edge e;

    _len = p._len;
    G = p.G;
    add_first_node(p.sink());
    for (p.reset(e); !p.end(); p.next(e))
        prepend(e);
    return p;
    }

void tree_to_path(path &P, edge *pred, node sink, int debug)
    {
    node v;
    int i=0;
    if (!&(P))
      cout << endl << "No path!" << endl;
    if (P.exists()) P.clear();
    P.add_first_node(sink);
    for (v=sink; pred[P.G->inf(v)]!=0; v=P.G->opposite(v,pred[P.G->inf(v)]))
        {
        if (debug)
            cout << "Node: " << P.G->inf(v) << "\nEdge: " << P.G->inf(pred[P.G->inf(v)]) << endl;
        if ((++i)%250 == 0) 
	  cout << "Tree path iterations = " << i << endl;    
        P.prepend(pred[P.G->inf(v)]);
        }
    }



ostream& operator << (ostream& os, path& p)
    {
    node v;
    edge e;
    list_item it=p.L.get_iterator();

    os << "Listing path from sink to source.\n";
    for (p.reset(v,e); !p.end(); p.next(v,e))
        {
        os << "\nNode:"; p.G->Print(v,os);
        os << "\nEdge:"; p.G->Print(e,os);
        }
    os << "\nNode:"; p.G->Print(v,os);
    p.L.set_iterator(it);
    if (p.iterating())
        {
        os << "\nCurrent node: "; p.G->Print(p.current_node(),os);
        os << "\nCurrent edge: "; p.G->Print(p.current_edge(),os);
        os << "\n\t" << p.current_edge();
        }
    else os << "\nNot iterating.";
    os << "\nLength: " << p.length() << endl;
    return os;
    }
