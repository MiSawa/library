#include "concur.h"

cflow::~cflow()
    {
    int i;
    for (i=1; i<=numcom; i++) delete com[i];
    delete [] com;
    delete [] LPseen;
    delete [] INDEG;
    delete [] KCseen;
    delete [] pred;
    delete [] dist;
    delete [] shortestPathList;
    delete heap;
    delete my_queue;
    delete st;
    }

double cflow::findShortPath(commodity *com,Dist mindist, Dist maxdist)
    {

/* 
  First, compare the two methods. 
*/
      shortest_path(G,com->source,com->sink,mindist,maxdist,dist,pred,
		    heap,shortestPathList);
      tree_to_path(com->shortpath,pred,com->sink);
      com->shortpath.recompute_length();
/*      cout << "With old version: length() = " << com->shortpath.length()
	<< endl;*/

/*      if (!bellman_fnord(G,com->source,com->sink,mindist,maxdist,dist,
			 pred, my_queue)  )
      tree_to_path(com->shortpath,pred,com->sink);
      com->shortpath.recompute_length();
*/
/*      cout << "With new version: length() = " << com->shortpath.length()
	<< endl;*/

/*      if (!bellman_fnord(G,com->source,com->sink,mindist,maxdist,dist,
			 pred ) )
	{
	cout << "Could be in trouble: source-sink path might not exist "<<endl;
	cout << "Connection exists: ";
	cout << (are_connected( G, com->source, com->sink )?
		 "TRUE" : "FALSE" ) << endl;
	cout << "Between nodes " << com->source << " " << com->sink << endl;
	com->cf->G.print();
	cout << "Didn't find sink! Iteration: " << reps << endl;
	cout << "Source = " << com->cf->G.inf(com->source) << "\tSink = " << com->cf->G.inf(com->sink) << endl;
	cout << "Alpha = " << com->cf->alpha << "\tBeta = " << com->cf->beta << endl;
	cout << "Mindist = " << mindist << "\tMaxdist = " << maxdist << endl;
	exit(1);
	}

    tree_to_path(com->shortpath,pred,com->sink);
    com->shortpath.recompute_length();
*/
    return dist[G.inf(com->sink)];
    }

double cflow::findLongPath(commodity *com)
    {
    if (!longest_path (*com)) 
	{
	cout << "Flow graph is cyclic.\n";
	cout << "Stopped at commodity " <<com->number << endl;
	exit(1);
	}
    tree_to_path(com->longpath,pred,com->sink);
    com->longpath.recompute_length();
    return dist[G.inf(com->sink)];
    }
/*
double cflow::findRandPath(commodity *com)
    {
    com->longpath.clear();
    com->longpath.add_first_node(com.sink);
    
    }  
*/
float cflow::estimateApprox(float& alphaRatio, float& iterRatio, double& cong,
			    double& tot_length )
    {
    int i;
    double A=0,B=0,C=0,maxflow=-1;
    edge e;

    forall_edges (e,G) 
	{
	maxflow = MAX(maxflow, G.inf(e).flow());
	A += G.inf(e).len();
	B += G.inf(e).flow() * G.inf(e).len();
	}
    cout << "Length sum = " << A << endl;
    tot_length = A;

    A *= maxflow;
    for (i=1,C=0; i<=numcom; i++)
	C+=com[i]->shortpath.length()*com[i]->demand;
    alphaRatio = A/B;
    iterRatio = B/C;
    cong = maxflow;
    return A/C;
    }

void cflow::increase_alpha()
    {
    edge e;
    alpha += 0.25;
    forall_edges(e,G) G.inf(e).update_len();
    }


void cflow::update_beta()
    {
    edge e;
    double oldbeta = beta;

    beta = 0;
    forall_edges(e,G) beta = MAX(beta,G.inf(e).flow());
    beta *= alpha;
    forall_edges(e,G) G.inf(e).update_len(oldbeta,beta);  // Scales
    st->scale(length_scale(oldbeta,beta));
    }

double cflow::best_flow( const commodity *com, double max_flow )
{
  double t1, t2;
  double bdf = best_dflow( com );

  if ( bdf < 0.0 )
    bdf = 0.0;

  if ( max_flow < bdf )
    return( max_flow );
  else {
/*    cout << "Here goes..." << endl; */
    return( exp( alpha * (max_flow-1.0) ) );
  }
}

int cflow::number_of_sigmas(const commodity *com, double maxflow)
{
  int n1,n2,maxn;
  double bdf = best_dflow(com), t1, t2; // t,l,dp,s;

/*
    t = exp(alpha*bdf);
    l = com->longpath.length();
    s = com->shortpath.length();
    dp = l/t+t*l;
*/
  if (bdf<0) {
    bdf = 0;
  }
//    cout << "BDF = " << bdf << "    sigma = " << com->sigma << endl;
  n1 = (int)(bdf/SIGMA(com));
  n2 = n1 + 1;
  maxn = (int)(maxflow/SIGMA(com));
  if ((maxn < n1) || (maxflow<bdf)) return maxn;
  if (maxn < n2) return n1;


/*
    cout << "n1 = "<< n1 << "    n2 = " << n2 << "    maxn = " << maxn 
      << " longest " << com->longpath.length() 
	<< " shortest " << com->shortpath.length() << endl;
*/

  t1 = exp(alpha*(SIGMA(com))*n1);
  t2 = exp(alpha*(SIGMA(com))*n2);
/*
  cout << "Returning: " <<  ( (com->longpath.length()/t1 + t1*com->longpath.length() <
	  com->longpath.length()/t2 + t2*com->longpath.length()) ?
	    n1 : n2 ) << endl;

*/

  return (com->longpath.length()/t1 + t1*com->longpath.length() <
	  com->longpath.length()/t2 + t2*com->longpath.length()) ?
	    n1 : n2;
}

double removable_flow (commodity* com)
{
    edge e;
    node v;
    dedge ce;
    double fl=Infinity;

    for (com->longpath.reset(v,e); !com->longpath.end(); com->longpath.next(v,e))
	{
	ce = com->corr_edge(e,v);
	if (ce == 0)
	    return 0.0;
	fl=MIN(fl,com->flowG.inf(ce).flow);
	}
    return fl;
  }


ostream& operator << (ostream& os, comedge& ce)
    {
    os << "ID = " << ce.id << "\tFlow = " << ce.flow;
    return os;
    }

ostream& operator << (ostream& os, commodity& c)
    {
    os << "Source: " << c.source << "\tSink: " << c.sink << "\tDemand: " << c.demand;
    return os;
    }

void print_tree (const node_array(edge)& t, const cfgraph& G)
    {
    node v;
    forall_nodes (v,G) cout << "\n" << G.inf(v) << G.inf(t[v]);
    }

cfedge::cfedge(double _c)
    {fl=0; c=_c; cf=0;}
cfedge::cfedge(cflow *_cf, double _c)
    {fl=0; c=_c; cf=_cf; l=cf->length(fl);}


/*
  This will almost compute an entire minimum spanning tree.  The point
  is to get the cut at the penultimate step.  At that point, we've found
  the cut (wrt the length) whose minimum length edge is maximized.
  Somehow, we'll translate this into an actual estimate.

  For honesty's sake, it should be noted that this incarnation of the mst
  algorithm is cribbed largely from the LEDA manual.

  --jda
*/

edge_array(real) costs;

int cmp_edges(edge& e, edge& f)
{
/*  return( e.len() - f.len() ); */
  if ( (costs)[e] < (costs)[f] )
    return( -1 );
  if ( (costs)[e] > (costs)[f] )
    return( 1 );
  return( 0 );
}

float cflow::mst_estimate() 
{
  node v, w;
  edge e;
  edge last_edge;
  int num_edges_added = 0;
  float flow_across_cut = 0.0;
  float edges_across_cut = 0.0;
  float total_length = 0.0;
  float length_across_cut = 0.0;
  float congestion;

  costs.init(G);

  node_partition queue(G);
  list(edge) ordered_edge_list = G.all_edges();
  forall_edges( e, G )  {
    (costs)[e] = G.inf(e).len();
/*    cout << "Adding edge with length " << G.inf(e).len() 
      << "\n"; */
  }
  ordered_edge_list.sort( cmp_edges );

  forall( e, ordered_edge_list )  {
    v = G.source(e);
    w = G.target(e);
    if ( !(queue.same_block(v,w)) )  {
      num_edges_added++;
      if ( num_edges_added == G.number_of_nodes() - 1 ) 
	last_edge = e;		/* Could abort loop, but I don't know how */
      else 
	if ( num_edges_added < G.number_of_nodes() - 1 )
	  queue.union_blocks(v,w);
    }
  }

/* 
  Now, go through and see how much length there is across the cut and in toto.
*/
  forall( e, ordered_edge_list )  {
    v = G.source(e);
    w = G.target(e);
    if ( !(queue.same_block(v,w)) )   {
      flow_across_cut += G.inf(e).flow();
      edges_across_cut += 1.0;
      length_across_cut += G.inf(e).len();
    }
    total_length += G.inf(e).len();
  }
/*
  Is this what I really want to return?
*/
  return( length_across_cut );

/*  congestion = flow_across_cut / edges_across_cut;
  return( congestion );*/
}
      

void cflow::dump_flow( char *file_name )
{
  edge e;

  ofstream outfile( file_name, ios::out );

  if (!outfile) {
    cout << "File " << file_name << " can not be opened for output.\n";
    return;
  }
  outfile << "p mcf " 
    << G.number_of_nodes() 
      << " " 
	<< G.number_of_edges() 
	  << " " 
	    << numcom 
	      << endl;

  forall_edges( e, G )
    outfile << "a " 
      << index(G.source(e)) + 1
	<< " " 
	  << index(G.target(e)) + 1
	    << " " 
	      << G.inf(e).flow()
		<< endl;;
}
