/*
   Member and friend functions for commodity, cflow, cfnode, cfedge, comedge.
*/

#include "basic.h"
#include "edgenode.h"
#include "mygraph.h"
#include "concur.h"
#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include "array.h"

declare (array,node)

extern long reps;
extern char zz;

ostream& operator << (ostream& os, comedge& ce)
    {
    os << "ID = " << ce.id << "\tFlow = " << ce.flow;
    return os;
    }

ostream& operator << (ostream& os, commodity& c)
    {
    os << "Source: " << c.source << "\tSink: " << c.sink << "\tDemand: " << c.demand;
    return os;
    }

void print_tree (const node_array(edge)& t, const cfgraph& G)
    {
    node v;
    forall_nodes (v,G) cout << "\n" << G.inf(v) << G.inf(t[v]);
    }

cfedge::cfedge(double _c)
    {fl=0; c=_c; cf=0;}
cfedge::cfedge(cflow *_cf, double _c)
    {fl=0; c=_c; cf=_cf; l=cf->length(fl);}
