#include "concur.h"
#include "graph.h"
#include "graph2.h"
#include "myprof.h"
extern char zz;

declare(list,dnode)

void reduce_indeg_of_target(commodity& com, node u, edge e, list(dnode)& ZEROINDEG)
    {
    if (com.corr_node[u]!=0)
	{
	if (com.corr_edge(e,u)==0) com.cf->INDEG[com.cf->G.inf(u)]--;
	if (com.cf->INDEG[com.cf->G.inf(u)]==0)
	    {
	    ZEROINDEG.append(com.corr_node[u]);
	    com.cf->LPseen[com.cf->G.inf(u)]=1;
	    }
	}
    }

void print_flow(const commodity& com)
    {
    dnode   v,u;
    dedge   e;
    int    id, id2;
    edgeListElt *elep;

    dforall_nodes (v,com.flowG)
	{
	id = com.cf->G.inf(com.flowG.inf(v));
	cout << "\nNode " << id << " sends ";
	dforall_out_edges (e,v,com.flowG,elep)
	    {
	    u = com.flowG.opposite(v,e);
	    id2 = com.cf->G.inf(com.flowG.inf(u));
	    cout << "\n    " << com.flowG.inf(e).flow << " to " << id2;
	    }
	}
    cout << endl;
    }

void kill_a_cycle (commodity& com, list(dnode)& ZEROINDEG)
    {
    edge e,last_e;
    node u,v;   // e,u,v are in G
    dnode v1,vv;
    dedge e1;
    edgeListElt *elep;
    double minflow;
    int id;

	      // KCseen = seen by kill_a_cycle?
	      // LPseen = seen by longest_path?

    for (id=1; id<=com.cf->G.number_of_nodes()+1; id++) com.cf->KCseen[id]=0;
    dforall_nodes(v1,com.flowG) if (!com.cf->LPseen[com.id(v1)]) break; // v1 temporarily in flowG
    if (v1==0)
	{
	cout << "Can't kill any cycles.  All nodes have been seen.\n";
	exit(1);
	}
    v = com.flowG.inf(v1);
    path p(com.cf->G,v);
    while (!com.cf->KCseen[com.id(v1)])
	{
	com.cf->KCseen[com.id(v1)]=true;   // Seen by this function
	dforall_in_edges(e1,v1,com.flowG,elep)
	    if (!com.cf->LPseen[com.id(com.flowG.opposite(v1,e1))]) break;
	if (e1==0)
	    {
	    cout << "No unseen incoming edges.\n";
	    com.flowG.print();
	    cout << "\nNode #" << com.id(v1) << endl;
	    exit(1);
	    }
	e = com.flowG.inf(e1).Gedge;
	p.append(e);
	v1 = com.flowG.opposite(v1,e1);
	}
    v = com.flowG.inf(v1);

    p.reset(u,e);
    minflow = com.flowG.inf(com.corr_edge(e,u)).flow;
    p.next(u,e);
    while (u!=v)
	{
	minflow = MIN(minflow,com.flowG.inf(com.corr_edge(e,u)).flow);
	p.next(u,e);
	}

    p.reset(u,e);
    com.incflow(e, com.flowG.inf(com.flowG.target(com.corr_edge(e,u))),-minflow);
    p.next(u,e);
    while (u!=v)
	{
	com.incflow (e,com.flowG.inf(com.flowG.target(com.corr_edge(e,u))),
		     -minflow);
	p.next(u,e);
	}

    p.reset(e);
    last_e = e;
    p.next(u,e);
    reduce_indeg_of_target(com,u,last_e,ZEROINDEG);
    while (u!=v)
	{
	last_e = e;
	p.next(u,e);
	reduce_indeg_of_target(com,u,last_e,ZEROINDEG);
	}
    }

bool longest_path(commodity& com)
    {
    list(dnode) ZEROINDEG;

    int vid,uid;
    int count=0,debug=0;
    dnode u,v;
    dedge e;
    real c;
    edgeListElt *elep;

    dforall_nodes(v,com.flowG)
	{
	com.cf->INDEG[com.id(v)] =indeg(v);
	com.cf->dist [com.id(v)] = -Infinity;
	com.cf->LPseen [com.id(v)] = 0;  // Not seen by longest path or kill_a_cycle
	}
    ZEROINDEG.append(com.corr_node[com.source]);
    com.cf->LPseen[com.cf->G.inf(com.source)] = 1;
    com.cf->dist[com.cf->G.inf(com.source)] = 0;
    com.cf->pred[com.cf->G.inf(com.source)] = 0;  // Source has no pred
    while (count<com.flowG.number_of_nodes())
	{
	u=ZEROINDEG.pop();
	uid = com.id(u);
	count++;
	dforall_out_edges(e,u,com.flowG,elep)
	    {
	    v = com.flowG.target(e);
	    vid = com.id(v);
	    if (debug) cout << "Node: " << com.id(u) << " looking at node: " << com.id(com.flowG.opposite(u,e)) << "\n";
	    c = com.cf->dist[uid] + com.cf->G.inf(com.flowG.inf(e).Gedge).len();
	    if (c > com.cf->dist[vid])
		{
		if (debug) cout << "Updating " << com.id(v) << " with value " << c << endl;
		com.cf->dist[vid] = c;
		com.cf->pred[vid] = com.flowG.inf(e).Gedge;
		}
	    if (--com.cf->INDEG[com.id(v)]==0)
		{
		ZEROINDEG.append(v);
		com.cf->LPseen[com.id(v)] = 1;  // Seen by this function
		}    
	    }
	while (ZEROINDEG.empty() && (count<com.flowG.number_of_nodes()))
	    kill_a_cycle(com,ZEROINDEG);
	}
    return 1;
    }

//declare (node_pq,real)

		       
bool shortest_path (const cfgraph &G, node source, node sink,
		    double minlength, double maxlength,
		    double dist[], edge pred[], 
		    NodeHeap* heap,
		    node bfslist[],
		    int debug)
    {int bfslistsize;
Dist candidateDist,len,mindist;
    node             u,v;
    edge             e;
     
     MARK(SP);
     heap->init();
     heap->insertNode(source,0.0);      
     pred[G.inf(source)] = 0; /*mark end of path */
     while (heap->notEmptyP())
       { 
	 MARK(SP1);
	 bfslistsize = 1;
	 mindist = heap->minDist();
	 bfslist[0] = heap->removeMin();     /* return index of node */
	 do
	  {
	    MARK(SP2);
	    u = bfslist[--bfslistsize];
		    
	    if (u == sink)                         /* check if sink is hit */
	      return TRUE;

	    forall_adj_edges(e,u)
	    {
	      MARK(SP3);
	      len = G.inf(e).len();
	      if (len > maxlength) 
		continue;
	      v = G.opposite(u,e);
	      if (heap->removedFromP(v)) 
		continue;
	      if (len < minlength)
		{
		  MARK(SP4);
		   bfslist[bfslistsize++] = v;
		   dist[G.inf(v)] = mindist;
		   pred[G.inf(v)] = e;
		   if (heap->inQueueP(v))
		     heap->removeNode(v);
		   else
		     heap->markAsRemoved(v);
		 }
	      else
		{candidateDist = mindist + len;
		 if (heap->inQueueP(v))
		   {if (heap->distOf(v) > candidateDist)
		     {
		       MARK(SP5);
		       heap->decreaseKey(v,candidateDist);
		      dist[G.inf(v)] = candidateDist;
		      pred[G.inf(v)] = e;
		    }
		  }
		 else /*not in heap */
		   {heap->insertNode(v,candidateDist);
		    dist[G.inf(v)] = candidateDist;
		    pred[G.inf(v)] = e;
		  }
	       }
	    }
	  } while (bfslistsize>0);
       }
return FALSE;
   }

/*
  This is largely ripped off from the LEDA manual.  The values minlength
  and maxlength are passed around to ensure compatibility, but they're
  not actually used.
*/

bool bellman_fnord( const cfgraph &G, node source, node sink,
		    double minlength, double maxlength,
		    double dist[], edge pred[], my_queue_type *my_queue )
{
  node_array(bool) in_queue(G, false );
  node_array(int) count(G, 0 );

  int n = G.number_of_nodes();
/*
  b_queue(node) *my_queue = new b_queue(node)(n);
*/
/*
  cout << "Initializing bounded queue with " << n << " nodes " << endl;
  cout << "Queue size: " << my_queue->size() << endl;
*/
  node u, v;
  edge e;
  double c;


/*
  cout << "Bellman-Fnord: source = " << G.inf(source) << " sink = "
    << G.inf(sink) << endl;
*/
/* Initialize the arrays. */

  MARK(BF1);
  forall_nodes( v, G )  {
    pred[ G.inf(v) ] = 0;
    dist[ G.inf(v) ] = maxlength;
    in_queue[ v ] = false;
  }

  MARK(BF2);
  dist[ G.inf( source ) ] = 0;
  my_queue->append( source );
  in_queue[ source ] = true;

  MARK(BF3);
  while ( (!my_queue->empty()) ) {
    MARK(BF4);
    u = my_queue->pop();
    in_queue[ u ] = false;
    if ( ++count[u] > n )
      return( false );		/* Negative cycle */
    
    forall_adj_edges( e, u )  {
    MARK(BF5);
      v = G.opposite( u, e );
      c = dist[ G.inf(u) ] + G.inf(e).len();

      if ( c < dist[ G.inf(v) ] )  {	/* See if we can improve dist[ v ] */
	MARK(BF6);
	dist[ G.inf(v) ] = c;
	pred[ G.inf(v) ] = e;
	if ( !in_queue[ v ] )  {
	  MARK(BFQAPP);
	  my_queue->append( v ) ;
	  in_queue[ v ] = true;
	}
      }
    }
  }

/*
  cout << "All done" << endl;
*/
/*  delete my_queue; */
  return( true );
}
	  



bool are_connected( const cfgraph &G, node source, node sink )

{
  node_partition queue(G);
  edge e;

  forall_edges( e, G )
    queue.union_blocks( G.source(e), G.target(e) );
  return( queue.same_block( source, sink ) );
}

