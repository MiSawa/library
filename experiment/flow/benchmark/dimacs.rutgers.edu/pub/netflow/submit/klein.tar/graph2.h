#ifndef _GRAPH2_H_
#define _GRAPH2_H_

/*

These are graphs that are smaller than LEDA's graphs but look the same for our
purposes.  These graphs also have the constraint that there is only one edge between
any two nodes, as is true for all flow graphs.

*/

class DIRedge;
class DIRnode;

typedef void*    ent;  
typedef DIRnode* dnode;
typedef DIRedge* dedge;

class edgeListElt
    {
    public:
        dedge edge;
        edgeListElt *next_edge;
    };

class DIRnode
    {
    friend class DIR;

    void      *inf;
    int        indeg,outdeg;
//    graph     *g;
    edgeListElt    *in_adj_list,*out_adj_list;
    dnode      next_node;

    friend int indeg (dnode v) {return v->indeg;}
    friend int outdeg(dnode v) {return v->outdeg;}
    };

class DIRedge
    {
    friend class DIR;

    void      *inf;
    dnode      ep1,ep2;   // Endpoints
    char       dir;       // Direction: 1 = from 1 to 2, 0 = from 2 to 1.
    };

class DIR
    {
    public:
        DIR () {nodes=edges=0; node_list=0;}
        virtual ~DIR () {clear();}
    
        ent   inf(dnode v) const {return v->inf;}
        ent   inf(dedge e) const {return e->inf;}
        dnode source(dedge e) const {return e->dir ? e->ep1 : e->ep2;}
        dnode target(dedge e) const {return e->dir ? e->ep2 : e->ep1;}
        int   indeg (dnode v) const {return v->indeg;}
        int   outdeg(dnode v) const {return v->outdeg;}
        int   number_of_nodes() const {return nodes;}
        int   number_of_edges() const {return edges;}
    
        void  assign (dnode,ent);
        void  assign (dedge,ent);
        void  del_edge (dedge);
        dedge new_edge (dnode, dnode, ent=0);
        void  del_node (dnode);
        dnode new_node (ent=0);
        void  clear();

        dnode first_node()             const {return node_list;}
        dnode succ_node(dnode v)       const {return v->next_node;}
        edgeListElt *first_out_elep(dnode v)  const {return v->out_adj_list;}
        edgeListElt *first_in_elep(dnode v)   const {return v->in_adj_list;}
        edgeListElt *succ_elep(edgeListElt *elep)
                  const {return elep->next_edge;}

    private:
        dnode      node_list;
        int        nodes,edges;

        int del_from_adj_list (edgeListElt**, dedge);
    };

inline dedge EDGE(edgeListElt *elep) {return elep==0 ? 0 : elep->edge; }

#define dforall_nodes(v,G) for (v=(G).first_node(); v; v=(G).succ_node(v))
#define dforall_out_edges(e,v,G,elep) for (elep=(G).first_out_elep(v), e=EDGE(elep); elep; elep=(G).succ_elep(elep), e=EDGE(elep))
#define dforall_in_edges(e,v,G,elep) for (elep=(G).first_in_elep(v), e=EDGE(elep); elep; elep=(G).succ_elep(elep), e=EDGE(elep))
#define dforall_edges(e,G,v,elep) dforall_nodes(v,G) dforall_out_edges(e,v,G,elep)

#endif
