// ------------------------------------
// Prototypes
// ------------------------------------

#ifndef _CONCUR_H_
#define _CONCUR_H_ 1

#include "basic.h"
#include "mygraph.h"
#include "cfgraph.h"
#include "heap.h"
#include "edgenode.h"
#include "b_queue.h"
#include <iostream.h>
#include <stdlib.h>

#define absol(x) ((x)>0 ? (x) : (-(x)))
#define MIN(x,y) ((x)>(y) ? (y) : (x))
#define MAX(x,y) ((x)<(y) ? (y) : (x))
#define MAXDIST 1e100
#define MINDIST 1e-50

const double FLOWTOL = 1.4e-16;

extern long reps;

typedef int stkey;

inline void swap (int &a, int &b)
    { int t=a; a=b; b=t; }

inline void swap (node &a, node &b)
    { node t=a; a=b; b=t; }

declare(node_pq,real)

void here(char*);
bool longest_path(commodity&);
bool shortest_path (const cfgraph&, node, node, double,double, double[],
       edge[], NodeHeap*, node[], int=0);
bool bellman_fnord (const cfgraph&, node, node, double,double, double[],
       edge[], my_queue_type *my_queue );
double removable_flow (commodity*);
bool are_connected( const cfgraph&, node, node );

/*
inline double potential_dec(commodity *com, double longlen, double shortlen, double flow)
    {
    return  longlen*(1-com->cf->length(-flow))
	   +shortlen*(1-com->cf->length(flow));
    }
*/

#endif
