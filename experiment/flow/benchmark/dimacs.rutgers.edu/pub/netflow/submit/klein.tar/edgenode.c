/*
   Member and friend functions for commodity, cflow, cfnode, cfedge, comedge.
*/

#include "basic.h"
#include "edgenode.h"
#include "mygraph.h"
#include "concur.h"
#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include "array.h"

declare (array,node)

extern long reps;
extern char zz;

