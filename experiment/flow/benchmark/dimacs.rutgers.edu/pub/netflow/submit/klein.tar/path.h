#ifndef _PATH_H_
#define _PATH_H_

#include "mygraph.h"

class cfgraph;

struct pathListElt
    {
    node v;
    edge e;  // The neighboring edge of v that is closer to the source
    };

typedef pathListElt* plep;
declare(list,plep)

class path
    {
        friend ostream& operator << (ostream&,path&);
    public:
        cfgraph    *G;

        // Access functions
        node source() const {return L.tail()->v;}
        node sink() const {return L.head()->v;}
        double length() const {return _len;}
        bool exists() const { return !L.empty(); }
        node current_node() const;
        edge current_edge() const;
        bool iterating() const { pathListElt *x; return L.current_element(x); }

        //Iterators
        void reset(node&);
        void reset(edge&);
        void reset(node&, edge&);
        void next(node&);
        void next(edge&);
        void next(node&, edge&);
        bool end() const
            { pathListElt *x; L.current_element(x); return x->e==0; }

        // Modifiers
        path(cfgraph&);
        path(cfgraph&, node);
        ~path() {clear();}
        void clear();
        void add_first_node(node v);
        node append(edge e);
        void truncate();   // Remove edge from end of path
        node prepend(edge e);
        void pretruncate(); // Remove edge from beginning of path
        double recompute_length();
        double length(double _l) {return (_len=_l);}
        path& operator=(path&);

    private:
        list(plep) L;
        double _len;

        pathListElt* Reset();
        pathListElt* Next();
        pathListElt* Current() const;
    };

void tree_to_path(path&, edge*, node, int=0);

/*
inline pathListElt* path::Reset()
    { pathListElt *x; L.init_iterator(); L.next_element(x); return x; }
inline pathListElt* path::Current() const
    { pathListElt *x; L.current_element(x); return x; }  
inline pathListElt *path::Next()
    { pathListElt *x; L.next_element(x); return x; }
inline void path::reset(node& v) { v=Reset()->v; }
inline void path::reset(edge& e) { e=Reset()->e; }
inline void path::reset(node& v, edge& e)
    { pathListElt *x=Reset(); v=x->v; e=x->e; }
inline void path::next(node& v) { v=Next()->v; }
inline void path::next(edge& e) { e=Next()->e; }
inline void path::next(node& v, edge& e)
    { pathListElt *x=Next(); v=x->v; e=x->e; }
inline node path::current_node() const { return Current()->v; }
inline edge path::current_edge() const { return Current()->e; }
*/
#endif

