#ifndef _HEAP_H_
#define _HEAP_H_ 1
#include "mygraph.h"
#include "myprof.h"
#define ROOT 1
#define SUBROOT 0
#define EMPTY -1.0
#define OUT 0
#define DIST_MIN -1.0
#define PARENT(num)	(num/2)
#define LEFTCHILD(num)	(num*2)               
#define RIGHTCHILD(num)	(LEFTCHILD(num) + 1)     
#define NOTNOW -32766

#define INLINE


class cfgraph;

typedef double Dist;
 struct HeapElt{
    node elt;
    Dist dist;
  };



class NodeHeap
    {
    public:
	NodeHeap(cfgraph*);
        ~NodeHeap();
        void init();
        void insertNode(node,Dist);
        Dist minDist();
        int notEmptyP();
        node removeMin();
        void removeNode(node);
        void decreaseKey(node,Dist);
        Dist distOf(node);
        bool inQueueP(node);
        bool removedFromP(node);
	void markAsRemoved(node);
	void print_inQ();
    private:
	void move(int,int);
	node remove(int);
	void downHeap(int);
	void upHeap(int);

	HeapElt* heapArray;
	int* positionArray;
	long* inQueueArray;
	long* removedArray;
	int numElemsIn;
	int TEMP;
	int maxNumElems;
	long currentTime;
	cfgraph* G;
    };



#endif

