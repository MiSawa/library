#ifndef _MYGRAPH_H_
#define _MYGRAPH_H_ 1
#include "edgenode.h"
#include "graph.h"
#include "graph2.h"
void here (char*);

//declare2(GRAPH,ent,ent)
declare2(UGRAPH,ent,ent)
//typedef GRAPH(ent,ent) DIR;
typedef UGRAPH(ent,ent) UNDIR;

class cfgraph : public UNDIR
    {
    private:
        ent store(const cfnode info)
            {cfnode *p=new cfnode(info); return (ent)p; }
        ent store(const cfedge info)
            {cfedge *p=new cfedge(info); return (ent)p; }
    public:
        ~cfgraph() { clear(); }
        node opposite(node v, edge e) const
            {if (source(e)==v) return target(e);
             else if (target(e)==v) return source(e); else return nil; }
        cfnode& inf(node v) const
            { return *((cfnode*)(UNDIR::inf(v))); }
        cfedge& inf(edge e) const
            {return *((cfedge*)(UNDIR::inf(e))); }
        void assign (node v, const cfnode info)
            {*((cfnode*)(UNDIR::inf(v)))=info; }
        void assign (edge e, const cfedge info)
            {*((cfedge*)(UNDIR::inf(e)))=info; }
        node new_node ()
            {cfnode *info = new cfnode; return new_node(*info);}
        edge new_edge (node v, node w)
            {cfedge info; return new_edge(v,w,info);}
        node new_node (const cfnode info)
            {node v; UNDIR::assign(v=UNDIR::new_node(),store(info)); return v; }
        edge new_edge (node v, node w, const cfedge info)
            {edge e; UNDIR::assign(e=UNDIR::new_edge(v,w),store(info)); return e; }
/*
Doesn't work with UNDIR=GRAPH(ent,ent)
        edge new_edge (node v, node w, edge e1, edge e2, cfedge info,
                       rel_pos dir1=after, rel_pos dir2=after)
            {edge e; UNDIR::assign(e=UNDIR::new_edge(v,w,e1,e2,dir1,dir2),store(info)); return e; }
*/
        void del_node (node v) {delete (cfnode*)(UNDIR::inf(v)); UNDIR::del_node(v);}
        void del_edge (edge e) {delete (cfedge*)(UNDIR::inf(e)); UNDIR::del_edge(e);}
        void del_all_nodes() {cout << "del_all_nodes is not supported.\n";}
        void del_all_edges() {cout << "del_all_edges is not supported.\n";}
        void clear();
        virtual void Print(node, ostream&) const;
        virtual void Print(edge, ostream&) const;
        void print_node(node v) const {Print(v,cout);}
        void print_edge(edge e) const {Print(e,cout);}
    };

class comgraph : public DIR
    {
    private:
        ent store(const node info)
            {node *p=new node(info); return (ent)p; }
        ent store(const comedge info)
            {comedge *p=new comedge(info); return (ent)p; }
    public:
        ~comgraph() { clear(); }
        dnode opposite(dnode v, dedge e) const
            {if (source(e)==v) return target(e);
             else if (target(e)==v) return source(e); else return nil; }
        node& inf(dnode v) const
            {return *((node*)(DIR::inf(v))); }
        comedge& inf(dedge e) const
            {return *((comedge*)(DIR::inf(e))); }
        void assign (dnode v, const dnode info)
            {*((dnode*)(DIR::inf(v)))=info; }
        void assign (dedge e, const comedge info)
            {*((comedge*)(DIR::inf(e)))=info; }
        dnode new_node ()
            {node *info = new node; return new_node(*info);}
        dedge new_edge (dnode v, dnode w)
            {comedge *info = new comedge; return new_edge(v,w,*info);}
        dnode new_node (const node info)
            {dnode v; DIR::assign(v=DIR::new_node(),store(info)); return v; }
        dedge new_edge (dnode v, dnode w, const comedge info)
            {dedge e; DIR::assign(e=DIR::new_edge(v,w),store(info)); return e; }
/*
Doesn't work with DIR=GRAPH(ent,ent)
        dedge new_edge (node v, node w, dedge e1, dedge e2, comedge info,
                       rel_pos dir1=after, rel_pos dir2=after)
            {dedge e; DIR::assign(e=DIR::new_edge(v,w,e1,e2,dir1,dir2),store(info)); return e; }
*/
        void del_node (dnode v) {delete (dnode*)(DIR::inf(v)); DIR::del_node(v);}
        void del_edge (dedge e) {delete (comedge*)(DIR::inf(e)); DIR::del_edge(e);}
        void del_all_nodes() {cout << "del_all_nodes is not supported.\n";}
        void del_all_edges() {cout << "del_all_edges is not supported.\n";}
        void clear();
        virtual void Print(dnode, ostream& = cout) const;
        virtual void Print(dedge, ostream& = cout) const;
        void print_node(dnode v) const {Print(v,cout);}
        void print_edge(dedge e) const {Print(e,cout);}
        void print(ostream& = cout) const;
    };


#endif
