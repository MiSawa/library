#ifndef _EDGENODE_H
#define _EDGENODE_H 1
#include "basic.h"
#include "graph.h"

class cflow;

class cfedge
    {
        friend ostream& operator << (ostream& os, cfedge& cfe)
            {cout << "ID = "<<cfe.id<<"\tFlow = "<<cfe.fl<<"\tCapacity = "<<cfe.c<<"\tLength = "<<cfe.l << endl; return os;}
    public:
        cflow     *cf;
        int id;   /* KILL THIS IN REAL VERSION */

        cfedge(double _c=1);
        cfedge(cflow *_cf, double _c=1);
        double incflow(double);
        double update_len();
        double update_len(double,double);
        double flow(double);
        double flow() const {return fl;}
        double cap()  const {return c;}
        double len()  const {return l;}
    private:
        double   l,fl,c;
    };

typedef int cfnode;

class comedge
    {
        friend ostream& operator << (ostream&,comedge&);
    public:
        int         id;
        edge        Gedge;  //Corresponding edge in G
        double      flow;   //Flow of this commodity through this edge
    };

#endif
