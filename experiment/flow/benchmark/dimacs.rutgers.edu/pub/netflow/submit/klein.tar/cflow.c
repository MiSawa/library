#include "concur.h"
#include <fstream.h>

cflow::cflow(ifstream& fin, double _alpha, double _capacity)
	       : alpha(_alpha), beta(0), st(0)
// This function reads the global graph in which the commodities will lie
// from the supplied file. Commodities (but not their flows) are also set up.
    {
    // Local variables
    string str;
    int nodes,edges,i,u,v,w,line,c=1;
    char ch;
    float error;
    cfedge info(this,_capacity); info.id = 0;

    fin >> ch >> str;
    if ((ch!='p') || (str!="mcf"))
	    {
	    cout << "Input file must be in Dimacs format.\n";
	    exit(1);
	    }
    fin >> nodes >> edges >> numcom;
    st = new sumtree(numcom);
    node *nodeArr = new node[1+nodes];
    for (i=1; i<=nodes; i++) nodeArr[i]=G.new_node(i);
    heap = new NodeHeap(&G);
    my_queue = new my_queue_type(1+G.number_of_nodes());
    shortestPathList = new node[G.number_of_nodes()];
    dist   = new double [1+G.number_of_nodes()];
    pred   = new edge   [1+G.number_of_nodes()];
    KCseen = new char   [1+G.number_of_nodes()];
    INDEG  = new int    [1+G.number_of_nodes()];
    LPseen = new char   [1+G.number_of_nodes()];

    line = 1;
    fin.get(ch);
    while ((ch=='a') || (ch=='\n'))
	{
	if (ch=='a')
	    {
	    fin >> u >> v >> w;
	    info.id++;
	    G.new_edge(nodeArr[u],nodeArr[v],info);
	    }
	fin.get (ch);
	}
    com = new commodity* [1+numcom];

    while ((ch=='k') || (ch=='\n'))
	{
	if (ch=='k')
	    {
	    fin >> u >> v >> w;
	    if (u==v)
		{
		cout << "Null commodity from "<<u<<" to "<<v<<" in line #"<<line<<" of input file.\n";
		exit(1);
		}
	    else
		{
		if (u>v) swap(u,v);
		if (c%50==0)cout<<"Read first "<<c<<" commodities."<<endl;
		com[c]=new commodity(this,nodeArr[u],nodeArr[v],w,c);
		c++;
		}
	    }
	fin.get(ch);
	}
    while (((ch=='e') || (ch=='\n')) && (!fin.eof()))
	{
	if (ch=='e') fin >> error;
	fin.get(ch);
	}
    update_beta();
    for (c=1; c<=numcom; c++)
	{
	com[c]->update_weight(); /* DOESN'T DO ANY GOOD -- WT=0 */
	st->add(com[c],1.0e30);
	}
    }

