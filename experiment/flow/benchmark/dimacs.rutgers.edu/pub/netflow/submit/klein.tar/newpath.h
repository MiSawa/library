#ifndef _PATH_H_
#define _PATH_H_

#include "basic.h"
#include "graph.h"
#include <stdlib.h>

class cfgraph;

class path
    {
        friend ostream& operator << (ostream&,path&);
    public:
        cfgraph    *G;
        node_array(edge) pred;

        // Access functions
        node source() const {return _source;}
        node sink() const {return _sink;}
        bool exists() const { return _sink!=0; }

        //Iterators
        void reset(node&);
        void reset(edge&);
        void reset(node&, edge&);
        void next(node&);
        void next(edge&);
        void next(node&, edge&);
        bool end() const { return cn==_source; }

        // Modifiers
        path(cfgraph& _G, node=0);
        void clear();
        void add_first_node(node v);
        node append(edge e);
        node prepend(edge e);

    private:
        node _source,_sink;
        node cn;  // Current node for iterators
    };

void tree_to_path(path&, edge*, node, int=0);

#include "cfgraph.h"

inline void path::add_first_node(node v)
    {
    if (exists())
        {
        cout << "Can not add node "; G->Print(v,cout);
        cout << "as first node.\nA first node has already been added." << endl;
        exit(1);
        }
    cn=_source=_sink=v;
    }

inline void path::reset(node& v)
    { if ((v=cn=_sink)==0) {cout << "No path to reset.\n"; exit(1); }}
inline void path::reset(edge& e)
    { if ((cn=_sink)==0) {cout << "No path to reset.\n"; exit(1);} e=pred[cn];}
inline void path::reset(node& v, edge& e)
    { if ((v=cn=_sink)==0) {cout<<"No path to reset.\n"; exit(1);} e=pred[cn];}
inline void path::next(node& v) { v=cn=G->opposite(cn,pred[cn]); }
inline void path::next(edge& e) { cn=G->opposite(cn,pred[cn]); e=pred[cn]; }
inline void path::next(node& v, edge& e)
    { v=cn=G->opposite(cn,pred[cn]); e=pred[v]; }



class LenPath : path
    {
    public:
        LenPath
        double length() const {return _len;}
        double recompute_length();
        double length(double _l) {return (_len=_l);}
    private:  
        double _len;
    }




#endif

