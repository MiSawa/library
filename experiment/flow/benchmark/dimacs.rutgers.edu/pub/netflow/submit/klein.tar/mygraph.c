#include "mygraph.h"


void cfgraph::clear()
    {
    node v;
    edge e;
    forall_edges (e,*this) delete (cfedge*)(UNDIR::inf(e));
    forall_nodes (v,*this) delete (cfnode*)(UNDIR::inf(v));
    UNDIR::clear();
    }


void cfgraph::Print(node v, ostream& os) const
    {
    os << inf(v);
    }


void cfgraph::Print(edge e, ostream& os) const
    {
    os << inf(e);
    }

void comgraph::clear()
    {
    dnode v;
    dedge e;
    edgeListElt *elep;
    dforall_edges (e,*this,v,elep) delete (cfedge*)(DIR::inf(e));
    dforall_nodes (v,*this) delete (cfnode*)(DIR::inf(v));
//    DIR::clear();    Called automatically because of inher.
    }


void comgraph::Print(dnode v, ostream& os) const
    {
    os << inf(v);
    }


void comgraph::Print(dedge e, ostream& os) const
    {
    os << inf(e);
    }

void comgraph::print (ostream& os) const
    {
    dnode v;
    dedge e;
    edgeListElt *elep;

    dforall_nodes(v,*this)
        {
        Print (v,os);
        os << "\n    Outgoing edges: " << outdeg(v);
        dforall_out_edges (e,v,*this,elep)
            {
            os << "\n\t";
            Print(e,os);
            }
        os << "\n    Incoming edges: " << indeg(v);
        dforall_in_edges (e,v,*this,elep)
            {
            os << "\n\t";
            Print(e,os);
            }
        os << endl;
        }
    }
