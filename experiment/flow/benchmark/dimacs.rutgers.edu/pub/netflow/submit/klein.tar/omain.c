
/* Concurrent flow approximation */

#include "concur.h"
#include <fstream.h>
#include <time.h>
#include <string.h>
//#include <conio.h>
#include <stdio.h>
#include <new.h>

double  initial_alpha = 4;
double alpha_update_freq_fact = 2.0;
const int     seed = 21;
const int     print_sigma_freq = 500;
const char    tb = '\t';
const int     num_targets = 4;
const int max_iters = 200000;

int        sigma_update_tally = 2;
double idn=0;

char * LEDA_OP::op_list;
long reps;
const float selectionParam=0.9;
int rand_count=0;

int use_mst = TRUE; 
int use_global_sigma = FALSE;
int fixed_sigma = FALSE;
int use_sigma_after_all = FALSE;
int move_buttloads = FALSE;
double global_sigma = 1.0;

char zz;
/*
char *datafile_name = "/home/jab/concur/data/outc17.dim";
char *resfile_name  = "/home/jab/concur/output/outc17.res";
char *auxfile_name  = "/home/jab/concur/output/outc17.aux";
char *flowfile_name = "/home/jab/concur/output/outc17.flow";
*/

char *datafile_name = "/home/jab/concur/data/outc432.dim";
char *resfile_name  = "/home/jab/concur/output/outc432.res";
char *auxfile_name  = "/home/jab/concur/output/outc432.aux";
char *flowfile_name = "/home/jab/concur/output/outc432.flow";

void here (char *st)
{
cout << st << endl;
}

void out_of_memory()
    {
    cerr << "Out of memory error on iteration " << reps << endl;
    exit(1);
    }

double potential (cflow &cf)
{
  double maxflow=-1, lensum=0;
  edge e;
  
  forall_edges(e,cf.G)
    {
      lensum += cf.G.inf(e).len();
      maxflow = MIN(cf.G.inf(e).flow(), maxflow);
    }
  return maxflow*lensum;
}

void print_sigmas(cflow& cf)
    {
    for (int i=1; i<=cf.numcom; i++)
	cout << cf.com[i]->sigma << "\t";
    cout << "\n\n";
    }

void print_best_flows( cflow& cf)
{
  int i;

  for ( i = 1; i <= cf.numcom; i++ )
    cout << cf.best_dflow( cf.com[i] ) << tb ;
  cout << endl << endl;
}

int route (ofstream& outfile, ofstream& approxf, char* fname, double target[])
{
  int        i,n,debug=0;
  commodity  *com;
  double     rf,congestion;
  double tot_length = 0.0;
  double     jda_error;
  double     error;
  int        beta_update_freq,alpha_update_freq,TAcount=0;
  int mst_update_freq;
  long       s,*tloc=0,t = (time_t)time(tloc);
  double flow_to_move;		/* Used if we're not using sigma */
  double bdf;			/* best delta flow -- best flow to move */

  ifstream infile(fname,ios::in);
  if (!infile)	{
    cout << "File " << fname << " can not be opened for input.\n";
    return 1;
  }
  cflow   cf(infile,initial_alpha);
  approxf << cf.G.number_of_nodes() << " nodes, " << cf.G.number_of_edges()
    << " edges, " << cf.numcom << " commodities.\n";

  float alphaRatio, iterRatio, errRatio;
  int over=0,tally0=0;
  stkey key;
  double total_rerouting=0;

  alpha_update_freq = (int)(cf.numcom * alpha_update_freq_fact) ;
  beta_update_freq = alpha_update_freq;
  mst_update_freq = alpha_update_freq / 2; /* Sure, it's arbitrary... */

  errRatio = Infinity;
  error = Infinity;
  cout.precision(4);
  approxf.precision(4);
  outfile.precision(4);

  outfile << "\nn\tm\tcom\teps\treps\terr\tcong\t??\t\ttime" << endl << endl ;


  if ( move_buttloads && global_sigma )
    use_sigma_after_all = TRUE;
  if ( fixed_sigma )
    use_sigma_after_all = TRUE;


  for (reps=1; TAcount<num_targets; reps++)  {
    if (reps%beta_update_freq==0)  {
      cf.update_beta();
      approxf << "Beta update at iteration " << reps << endl;
    }
    com = cf.bad_com(selectionParam,key);
    if (debug)
      com->print();
    if (reps%500==0) 
      cout << "after " << reps << " iterations, percent rerouting iterations is " << 100.0*(reps-tally0)/reps << endl;
    com->shortpath.recompute_length();
    n=0;

    if ( move_buttloads )  {
      if ( com->minflow > FLOWTOL )  {
	com->shortpath.recompute_length();
	com->longpath.recompute_length();
	rf = removable_flow( com );
	bdf =cf.best_dflow( com );
	flow_to_move = MIN( rf, bdf );
	if ( flow_to_move > 0.0 )  {
	  com->longpath.recompute_length();
	  rf = removable_flow( com );
	  bdf =cf.best_dflow( com );
	  flow_to_move = MIN( rf, bdf );
	}
      }
      if ( !(flow_to_move > 0.0) )  {
	cf.findLongPath( com );
	rf = removable_flow( com );
	bdf = cf.best_dflow( com );
	flow_to_move = MIN( rf, bdf );
	if ( !(flow_to_move > 0.0) )  {
	  cf.findShortPath( com,
			   com->longpath.length()/(4*cf.G.number_of_nodes()),
			   com->longpath.length() );
	  rf = removable_flow( com );
	  bdf = cf.best_dflow( com );
	  flow_to_move = MIN( rf, bdf );
	}
      }
      if ( flow_to_move > FLOWTOL )  {
	if ( use_sigma_after_all )
	  flow_to_move = global_sigma * (floor(flow_to_move/global_sigma));

	com->update_weight();
	cf.change_weight(com,key);
	
	com->minflow = rf - flow_to_move;
/*	cout << "Min flow wil be:  " << com->minflow << tb; */
	com->reroute_flow( flow_to_move, debug );
	total_rerouting += flow_to_move;
      }
    }
    else  {
      if (com->minflow > FLOWTOL)  {
	rf=removable_flow(com);
	if (rf> 0.0)  {
	  com->longpath.recompute_length();
	  n = cf.number_of_sigmas (com,rf);
	}
      }
      if (n==0)  {
	cf.findLongPath(com);
	n = cf.number_of_sigmas (com, rf=removable_flow(com));
	if (n==0) {
	  cf.findShortPath(com,
			   com->longpath.length()/(4*cf.G.number_of_nodes()),
			   com->longpath.length());
	  n = cf.number_of_sigmas (com, rf);
	  if ((n==0) && (++com->tally >=sigma_update_tally))  {
	    com->tally=0;
	    if (!fixed_sigma)
	      SIGMA(com) /= 2;
	    n = cf.number_of_sigmas(com,rf);
	  }
	}
      }
	
      if (n==0) tally0++;
      else over++;
      
      com->update_weight();
      cf.change_weight(com,key);
      if ( n!=0 )  {
	com->minflow = rf - n*SIGMA(com);
	com->reroute_flow (n,debug);
	total_rerouting += n*SIGMA(com);
      }
    }

    if (reps%alpha_update_freq==0) {
      for (i=1; i<=cf.numcom; i++)  {
	com = cf.com[i];
	cf.findShortPath(com,MINDIST,MAXDIST);
      }
      errRatio = cf.estimateApprox(alphaRatio,iterRatio,congestion,tot_length);

      jda_error = ( use_mst ? tot_length / cf.mst_estimate() : Infinity );

      error = MIN( jda_error, errRatio );

      if (alphaRatio > iterRatio)  {
	cf.increase_alpha();
	approxf << "Increased alpha to " << cf.alpha << " at iteration " << reps << endl;
	cout << "Alpha ratio = " << alphaRatio << "\nIter ratio = " << iterRatio << endl;
      }
      cout << "Actual approximation ratio is " << errRatio << endl << endl;
      approxf << reps << tb << errRatio << tb << congestion << tb << alphaRatio << tb << iterRatio << endl;
    }

    s = (time_t)time(tloc);
    while ((TAcount<num_targets) && ((error <= 1+target[TAcount]) ||
				     (reps > max_iters)))  {
      if ( reps > max_iters )
	outfile << "Aborted" << endl;
      outfile << cf.G.number_of_nodes() << tb << cf.G.number_of_edges() << tb << cf.numcom << tb << target[TAcount] << tb << reps << tb << error << tb << congestion << tb << reps-tally0 << tb << tb << s-t << endl;
      approxf << "Iterations = " << reps << "\nReroutings = " << reps-tally0 << "\nAchieved approx ratio = " << errRatio << "\nFinal congestion = " << congestion << "\nTime = " << s-t << endl << endl;
      outfile.flush();
      approxf.flush();
	  
      TAcount++;
    }
    if (debug) com->print();
  }
    if ( flowfile_name )
    cf.dump_flow( flowfile_name );
  return 0;
  }

void print_instructions()
{
  cout << "Usage: concur [options]" << endl;
  cout << "\t\t-o output (or results) file name" << endl;
  cout << "\t\t-a auxiliary file name" << endl;
  cout << "\t\t-i input file name" << endl;
  cout << "\t\t-s sigma update tally" << endl;
}

void print_parameters( ofstream& outfile ) 
{
  outfile << endl;
  outfile << "Data file: " << datafile_name << endl;
  outfile << "Aux file : " << auxfile_name << endl;
  outfile << "Res file : " << resfile_name << endl;
  outfile << "Sigma update: " << sigma_update_tally << endl;
  outfile << "Initial alpha " << initial_alpha << endl;
  outfile << "Alpha update freq fact " << alpha_update_freq_fact<< endl;
  outfile << ( use_global_sigma ? "" : "NOT " ) <<
    "Using global sigma" << endl;
  outfile << ( use_mst ? "" : "NOT " ) 
    << "Using alternate estimate for lower bound" << endl;
  outfile << ( move_buttloads ? "" : "NOT " ) 
    <<  "Moving as much flow as possible" << endl;
  outfile << "Host: " << getenv( "HOST" )  << endl;
  outfile << endl << endl << endl;
}

int main( int argc, char *argv[])
{
  int samples = 2;
  int i, j;

  double target[num_targets];
  target[0] = 0.1; target[1] = 0.05; target[2] = 0.025; target[3] = 0.0125; 
/*  target[0] = 0.203;target[1] = 0.193; target[2] = 0.14; target[3] = 0.084;*/

  set_new_handler( out_of_memory );

  for ( i = 1 ; i < argc ; i++ )  {
    if ( argv[i][0] == '-' ) 
      switch( argv[i][1] ) {
	case 'o':
	case 'r':
	resfile_name = strdup( argv[++i] );
	break;

	case 'a':
	if ( strcmp( argv[i], "-alpha" ) == 0 )
	  sscanf( argv[++i], "%lf", &initial_alpha );
	else if (sscanf( argv[i], "-alphaupdate" ) == 0 )
	  sscanf( argv[++i], "%lf", &alpha_update_freq_fact );
	else
	  auxfile_name = strdup( argv[++i] );
	break;

	case 'i':
	case 'd':
	datafile_name = strdup( argv[++i] );
	break;

	case 'f':
	if ( strcmp( argv[i], "-fixedsigma" ) == 0 )  {
	  fixed_sigma = TRUE;
	  use_global_sigma = TRUE;
	}
	else
	  flowfile_name = strdup( argv[++i] );
	break;

	case 's':
	if ( strcmp( argv[i], "-sigma" ) == 0 )
	  sscanf( argv[++i], "%lf", &global_sigma );
	else
	  sscanf( argv[++i], "%d", &sigma_update_tally );
	break;

	case 't':
	sscanf( argv[++i], "%lf", &(target[0]) );
	sscanf( argv[++i], "%lf", &(target[1]) );
	sscanf( argv[++i], "%lf", &(target[2]) );
	sscanf( argv[++i], "%lf", &(target[3]) );
	break;

	case 'm':
	if ( strcmp(argv[i],"-mst") == 0 )
	  use_mst = TRUE;
	else if ( strcmp(argv[i], "-movebuttloads" ) == 0 )
	  move_buttloads = TRUE;
	else {
	  cout << "Illegal option: " << argv[i] << endl;
	  print_instructions();
	  return( 1 );
	}	  
	break;

	case 'n':
	if ( strcmp(argv[i],"-nomst") == 0 )
	  use_mst = FALSE;
	else if ( strcmp(argv[i],"-noglobal") == 0 )
	  use_global_sigma = FALSE;
	else {
	  cout << "Illegal option: " << argv[i] << endl;
	  print_instructions();
	  return( 1 );
	}	  
	break;

	case 'g':
	if ( strcmp(argv[i],"-global") == 0 )
	  use_global_sigma = TRUE;
	else {
	  cout << "Illegal option: " << argv[i] << endl;
	  print_instructions();
	  return( 1 );
	}	  
	break;



	case 'h':
	print_instructions();
	return( 1 );
	default:
	cout << "Illegal option: " << argv[i] << endl;
	print_instructions();
	return( 1 );
      }
    else  {
      cout << "Illegal option: " << argv[i] << endl;
      print_instructions();
      return( 1 );
    }
  }

/* Print out parameters for this run. */
  cout << "Data file: " << datafile_name << endl;
  cout << "Aux file : " << auxfile_name << endl;
  cout << "Res file : " << resfile_name << endl;
  cout << "Sigma update: " << sigma_update_tally << endl;
  cout << ( use_global_sigma ? "" : "NOT " ) <<
    "Using global sigma" << endl;
  cout << ( use_mst ? "" : "NOT " ) <<  
  "Using alternate estimate for lower bound" << endl;
  cout << ( move_buttloads ? "" : "NOT " ) <<  
  "Moving as much flow as possible" << endl;

  cout << "Targets" << tb << target[0] << tb << target[1]
    << tb << target[2] << tb << target[3] << endl;

/* Now, try opening all the files. */  
  ofstream outfile(resfile_name,ios::app);
  if (!outfile)  {
    cout << "File " << resfile_name << " can not be opened for output.\n";
    return( 1 );
  }
  ofstream approxf( auxfile_name,ios::app);
  if (!approxf) {
    cout << "File " << resfile_name << " can not be opened for output.\n";
    return( 1 );
  }

  print_parameters( outfile );
  for (j=0; j<samples; j++)  {
    srand(seed+j);
    approxf << "Seed = " << seed+j << endl;
    route (outfile,approxf,datafile_name,target);
  }
}
