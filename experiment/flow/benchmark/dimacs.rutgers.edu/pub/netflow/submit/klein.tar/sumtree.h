#ifndef _SUMTREE_H_
#define _SUMTREE_H_

#define RAND_MAX 16384     // Uncomment for AT&T C++
#define TRUE 1
#define FALSE 0

extern int rand_count;
class commodity;

typedef int stkey;
typedef commodity* InfoClass;

class sumtreeNode
    {
    public:
        double          sum,value;
        InfoClass       info;
    };

class sumtree
    {
        friend ostream& operator<< (ostream&, const sumtree&);
    public:
        sumtree(int size=16);   /* Initial array size = 16 */
        ~sumtree();
        void scale (double);
	stkey add (const InfoClass&, double);
	void change (stkey, double);
	InfoClass select(double val) const {stkey k; return select(val,k);}
        InfoClass select(double,stkey&) const;
        InfoClass blindSelect(double,stkey&) const;
    private:
	sumtreeNode                 *arr;
	int                         size,numElts;
	double sum(stkey key) const
            { return (key>=numElts ? 0 : arr[key].sum); }
    };

inline sumtree::~sumtree()
    {
    delete [] arr;
    }

inline double unitrand()
    {
    rand_count++;
/*    return ((double)((rand()%RAND_MAX) / (RAND_MAX+1))); */
    return (double)(rand()%RAND_MAX) / (RAND_MAX+1);

    }

#endif
