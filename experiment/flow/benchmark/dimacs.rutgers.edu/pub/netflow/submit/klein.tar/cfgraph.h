
#ifndef _CFGRAPH_H
#define _CFGRAPH_H

#include "basic.h"
#include "edgenode.h"
#include "mygraph.h"
#include "path.h"
#include "sumtree.h"
#include "heap.h"
#include "b_queue.h"
#include <math.h>

class cflow;

declare(node_array,dnode)
declare(edge_array,dedge)
declare(b_queue,node)
typedef b_queue(node) my_queue_type;

class commodity
    {
        friend ostream& operator << (ostream&,commodity&);
    public:
        cflow                               *cf;
        comgraph                            flowG;
        double                              demand,sigma,weight;
        node                                source,sink;
        node_array(dnode)                   corr_node;
        int                                 number,large_sigma_count;
        path 			            longpath,shortpath;
//        edge_array(dedge)                   corr_edge;
        double                              minflow;
        int                                 tally;

        commodity(cflow *, node, node, double, int);
        void incflow (edge,node,double,int=0);
        void reroute_flow (int, int=0);
	void reroute_flow( double, int=0 );
        double update_weight();
        int  id(dnode) const;
        int  id(dedge) const;
	dedge corr_edge(edge,node,int=1);
	void print(void);
    private:
    };

class cflow
    {
    public:
        cfgraph                           G;
        double                            error,alpha,beta;
        commodity                         **com;   // Make private?
        int                               numcom;
        char *KCseen,*LPseen;
        int *INDEG;        
	double *dist;
	edge *pred;

//        cflow(ifstream&, double, double, double=1.0);
        cflow(ifstream&, double, double = 1.0);
        ~cflow();
        void increase_alpha();
        void update_beta();
        commodity *bad_com (float,stkey&);
        double length(double fl) { return exp(alpha*fl-beta); }
        double length_scale(double oldbeta, double newbeta)
            { return exp(oldbeta-newbeta); }
        double best_dflow(const commodity*);
        int number_of_sigmas(const commodity*, double);
        double best_flow(const commodity*, double);
	double estimateApprox(double&,double&,double&,double&);
	float mst_estimate_error();
	float mst_estimate();
        void change_weight (const commodity* com, stkey k)
            { st->change(k,com->weight); }
	double findShortPath(commodity*,Dist,Dist);
	double findLongPath(commodity*);
	void dump_flow( char *file_name );

    private:
        sumtree  *st;
	NodeHeap *heap;
	my_queue_type *my_queue;
	node *shortestPathList;
    };

inline commodity* cflow::bad_com(float param,stkey& key)
            { if (unitrand()> param) return st->blindSelect(unitrand(),key);
	      else return st->select(unitrand(),key);}
inline double cflow::best_dflow(const commodity *com)
    { return log(com->longpath.length()/com->shortpath.length())/(2*alpha); }
inline double cfedge::update_len()
    { return l=cf->length(fl); }
inline double cfedge::update_len(double oldbeta, double newbeta)
    { return l*=cf->length_scale(oldbeta,newbeta); }
inline double cfedge::incflow(double f)
    { fl+=f; return update_len(); }
inline double cfedge::flow(double f)
    { fl=f; return update_len(); }
inline int commodity::id(dnode v) const
    {return (v==0) ? -1 : cf->G.inf(flowG.inf(v));}
inline int commodity::id(dedge e) const
    {return (e==0) ? -1 : cf->G.inf(flowG.inf(e).Gedge).id;}

extern int use_global_sigma;
extern double global_sigma;


#define SIGMA(com) ( use_global_sigma ? global_sigma : com->sigma )


#endif
