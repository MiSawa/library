/* main.cc  by Andrew Goldberg
 *     Driver for all the sp algorithms.
 *
 */

#define RAND_TRIES 5
#define WALK_TRIES 10
#define WALK_LEN 16

#include <stdlib.h>       // for atoi
#include <stdio.h>        // for printf
#include "sp.h"           // shortest-path class
#include <string.h>

extern double timer();            // in timer.cc: tells time use
#ifdef SINGLE_PAIR
unsigned long internal_seed;
unsigned long long internal_seed_LL;
#include "randomCC.c"
extern int parse( long *n_ad, long *m_ad, Node **nodes_ad, Arc **arcs_ad, 
		  Node **source_ad, Node **sink_ad,
		  long *node_min_ad, char *problem_name );
#else
extern int parse( long *n_ad, long *m_ad, Node **nodes_ad, Arc **arcs_ad, 
		  Node **source_ad, long *node_min_ad, char *problem_name );
#endif

/*
#define SZ_DIK_SMARTQ   "Dijkstra with Smart Queues"
#define SZ_DIK_MLB      "Dijkstra with Multi-Level Buckets"
#define SZ_BFS          "Breadth-First Search"
*/
int main(int argc, char **argv)
{

  char SZ_DIK_SMARTQ[100];
  char SZ_DIK_MLB[100];
  char SZ_BFS[100];


   double tm = 0.0;
   Arc *arcs;
   Node *nodes, *source;
#ifdef SINGLE_PAIR
   Node *sink = NULL;
   long walkLen = WALK_LEN;
#endif
   Node *node;
   long n, m, nmin;
   char name[100];
   char szAlgorithm[100];
   double dist;
   long long maxArcLen, minArcLen;
   SP *sp;
   ulong cLevels;
   ulong logDelta;
   long param;
   bool doBFS = false;

   strcpy(SZ_DIK_SMARTQ, "Dijkstra with Smart Queues");
   strcpy(SZ_DIK_MLB, "Dijkstra with Multi-Level Buckets");
   strcpy(SZ_BFS, "Breadth-First Search");

#ifdef SINGLE_PAIR
   if ((argc < 2) || (argc > 3)) {
#ifdef MLB
     fprintf(stderr, 
"Usage: \"mbp 0 [steps]\"\n    or \"mbp <levels> [steps]\"\n    or \"mbp -<log delta> [steps]\"\n");
#else
     fprintf(stderr, 
"Usage: \"sqb 0 [steps]\"\n    or \"sqb <levels> [steps]\"\n    or \"sqp -<log delta> [steps]\"\n");
#endif
     exit(0);
   }
#else
   if (argc != 2) {
#ifdef MLB
     fprintf(stderr, 
"Usage: \"mlb 0\" or \"mlb <levels>\" or \"mlb -<log delta>\"\n");
#else
     fprintf(stderr, 
"Usage: \"sq 0\" or \"sq <levels>\" or \"sq -<log delta>\"\n");
#endif
     exit(0);
   }
#endif

   printf("c ---------------------------------------------------\n");
   printf("c MLB/SQ version 1.1. \n");
   printf("c Copyright C by IG Systems, Inc., igsys@igsystems.com\n");
   printf("c Commercial use requires a license\n");
   printf("c ---------------------------------------------------\n");

#ifdef SINGLE_PAIR
   parse( &n, &m, &nodes, &arcs, &source, &sink, &nmin, name );   // in parse_sp.c
#else
   parse( &n, &m, &nodes, &arcs, &source, &nmin, name );   // in parse_sp.c
#endif
   printf("c\n");

   ArcLen(n, nodes, &minArcLen, &maxArcLen);      // other useful stats

   // sanity check
   dist = (double) maxArcLen * (double) (n-1);
   if (dist > VERY_FAR) {
     fprintf(stderr, "Warning: distances may overflow\n");
     fprintf(stderr, "         proceed at your own risk!\n");
   }

   // figure out what algorithm to use
   cLevels = 0;
   logDelta = 0;
   strcpy(szAlgorithm, SZ_DIK_SMARTQ);
#ifdef MLB
   strcpy(szAlgorithm, SZ_DIK_MLB);
#endif
   param = atoi(argv[1]);

   if (param == -99) { // this special case goes first
     // do breadth-first search
     strcpy(szAlgorithm, SZ_BFS);
     doBFS = true;
   }
   else {
     if (param == 0) {
       // cLevel and delta will be optimized in smartq.cc
       cLevels = 0;
       logDelta = 0;
     }
     
     if (param > 0) {
       cLevels = (ulong) param;
     }
     
     if (param < 0) {
       logDelta = (ulong) -param;
     }
   }

#ifdef SINGLE_PAIR
   if (argc == 3) {
     walkLen = atoi(argv[2]);
   }
#endif


   sp = new SP(n, nodes, cLevels, logDelta, doBFS);

   if (doBFS) {  // get baseline timing
     tm = timer();
     dist = sp->BFS(source);
     tm = (timer() - tm);             // give an avg time

     ArcLen(n, nodes, &minArcLen, &maxArcLen);      // other useful stats
   
     printf("c %s (%s)\n", szAlgorithm, argv[1]);
     printf("c Nodes: %20ld       Arcs: %19ld\n",  n, m);
     printf("c Baseline timing\n");
     printf("c Time: %21.2f       MaxArcLen: %14lld\n", tm, maxArcLen);
     printf("c Found:%21.2f\n", dist);
     printf("\n");
   }
   else {
     dist = 0.0;
#ifdef SINGLE_PAIR
     sp->init(source);
     if (sink != NULL) {
       tm = timer();          // start timing
       sp->sp(source, sink);
       tm = (timer() - tm);   // finish timing
       
       dist = sink->dist;

       printf("c %s (%s) -> problem name: %s\n", szAlgorithm, argv[1], name);
       printf("c Nodes: %26ld       Arcs: %25ld\n",  n, m);
       /* *round* the time to the nearest .01 of a second */
       printf("c Time: %27.2f       MaxArcLen: %20lld\n", 
	      tm, maxArcLen);
       printf("c Dist: %27.2f       MinArcLen: %20lld\n", dist, minArcLen);
       
       // now print the sp-specific stats
       sp->PrintStats(1);
       printf("\n");
     }
     else {
       long i, j;
       Arc *a;

       // first measure the single source computation time
       tm = timer();          // start timing
       sp->sp(source, sink);
       tm = (timer() - tm);   // finish timing

       dist = 0.0;
       for ( node = nodes; node < nodes + n; node++ )
         // calculate dists sum of reachable nodes
	 if ( node->parent )
	   dist += node->dist;

       // *round* the time to the nearest .01 of a second
       printf("c %s (%s) -> problem name: %s\n", szAlgorithm, argv[1], name);
       printf("c Nodes: %26ld       Arcs: %25ld\n",  n, m);
       printf("c Single source time:  %12.2f       Dist: %25.0f\n", tm, dist);
       printf("c\n");

       // Now measure time to random sinks
       dist = 0.0;
       init_rand(31415);
       sp->initStats();
       tm = timer();
       for (i = 0; i < RAND_TRIES; i++) {
	 sink = nodes + nrand(n);
	 if (sp->sp(source, sink))
	   dist += sink->dist;
       }
       tm = timer() - tm;

       printf("c Rand avg. time: %17.2f       Dist:  %24.0f\n", 
	      (tm/(float) RAND_TRIES), dist);
       // now print the sp-specific stats
       sp->PrintStats(RAND_TRIES);
       printf("c\n");

       // Finally measure times to random walk ends
       dist = 0.0;
       sp->initStats();
       tm = timer();
       for (i = 0; i < WALK_TRIES; i++) {
	 sink = source;
	 for (j = 0; j < walkLen; j++) {
	   if (sink->first == (sink+1)->first)
	     break; // no outgoing arcs
	   a = sink->first + nrand((sink+1)->first - sink->first);
	   sink = a->head;
	 }
	 if (sp->sp(source, sink))
	   dist += sink->dist;
       }
       tm = timer() - tm;

       printf("c Walk steps: %21ld\n", walkLen);
       printf("c Walk avg. time: %17.3f       Dist:  %24.0f\n", 
	      (tm/(float) WALK_TRIES), dist);
       // now print the sp-specific stats
       sp->PrintStats(WALK_TRIES);
       printf("\n");

     }
#else
     tm = timer();          // start timing
     sp->init(source);
     sp->sp(source);
     tm = (timer() - tm);   // finish timing

     for ( node = nodes; node < nodes + n; node++ )         // calculate dists
       if ( node->parent )                                  // reachable
	 dist += node->dist;

     printf("c %s (%s) -> problem name: %s\n", szAlgorithm, argv[1], name);
     printf("c Nodes: %26ld       Arcs: %25ld\n",  n, m);
     /* *round* the time to the nearest .01 of a second */
     printf("c Time: %27.2f       MaxArcLen: %20lld\n", tm + 0.005, maxArcLen);
     printf("c Dist: %27.0f       MinArcLen: %20lld\n", dist, minArcLen);
     
     // now print the sp-specific stats
     sp->PrintStats();
     printf("\n");

#endif

   }

   sp->~SP();
   return 0;
}
