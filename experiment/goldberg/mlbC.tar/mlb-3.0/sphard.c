#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef CYGWIN
#include "values.h"
#else
#include <values.h> 
#endif

#include "random.c"
#include "permute.c"

/* generator of graphs meant to be hard for multiple-level bucket
   implementations but not to smart queues.
*/

int main (int argc, char *argv[])

{

  long n, m;
  long pLen, pNum, p, i;
  unsigned long levels, logDelta, delta;
  long long deltaL, deltaI;
  long caliber;
  long source;
  long seed;
  long *nodeArr;
  long v, w;

  /* parsing  parameters */

  if (argc != 6) goto usage;

  // first parameter - number of nodes
  n = atol(argv[1]);

  // second parameter - log(delta)
  logDelta = atol(argv[2]);
  delta = 1 << logDelta;

  // third parameter - number of levels
  levels = atol(argv[3]);

  if (levels * logDelta >= 64) {
    fprintf (stderr, "Error: L * D exceeds 63\n");
    exit(4);
  }

  if (levels < 1) {
    fprintf (stderr, "Error: L must be at least 1\n");
    exit(4);
  }

  // fourth parameter - caliber (0/none)
  caliber = atol(argv[4]);

  if ((caliber < 0) || (caliber > 1)) {
    fprintf (stderr, "Error: C must be 0 or 1\n");
    exit(4);
  }

  // compute path lengths
  printf("c input N %ld ", n);
  pNum = 2*levels + 1;
  pLen = (n-2) / pNum;

  if (pLen < 1) {
    fprintf (stderr, "Error: too few nodes for given D and L\n");
    exit(4);
  }

  n = pNum*pLen + 2;
  printf("adjusted to %ld\n", n);

  seed = atol(argv[5]);

  init_rand(seed);

  source = 1;
  nodeArr = (long *) calloc(n+1, sizeof(long));
#ifdef PERMUTE_NODES
  randomPerm(n, nodeArr, &source);
#endif

  // compute m
  m = pNum*pLen + n - 1;


  // compute delta^L
  deltaL = (long long) 1 << (logDelta * levels);

  printf("c sphard generator, levels %ld, delta %ld, pLen %ld\n",
	 levels, delta, pLen);

  // start printing
  printf("p sp %ld %ld\n", n, m);
  // source
  printf("n %ld\n", source);

  // first the source arcs
  {
    long long len;

    // zero
    v = 1;
    w = 2;
    printf("a %ld %ld 0\n", ID(v), ID(w));
    // first bunch
    len = deltaL - (long long) 1;
    deltaI = 1;
    for (i = 1; i <= levels; i++) {
      // len is (L-i) "9"s and i "0"s
      v = 1;
      w = i*pLen + 2;
      printf("a %ld %ld %lld\n", 
	     ID(v), ID(w), len);
      len = len - ((long long) (delta-1)) * deltaI; // erase a "9"
      deltaI = deltaI * (long long) delta;
    }

    // second bunch
    len = deltaL - (long long) 1;
    deltaI = 1;
    for (i = 1; i <= levels; i++) {
      // len is (L-i-1) "9"s and "1" and i "0"s
      v = 1;
      w = (levels+i)*pLen + 2; 
      printf("a %ld %ld %lld\n", 
	     ID(v), ID(w),
	     len - ((long long) (delta-2) * deltaI));
      len = len - ((long long) (delta-1)) * deltaI; // erase a "9"
      deltaI = deltaI * (long long) delta;
    }
  }

  // now paths
  deltaI = deltaL / (long long) delta;
  for (p = 0; p < pNum; p++)
    for (i = 1; i < pLen; i++) {
      v = p*pLen + i + 1;
      w = p*pLen + i + 2;
      printf("a %ld %ld %lld\n", 
	     ID(v), ID(w), deltaI);
    }

  // the last node has no incoming arcs
  // this node is connected to every node nut the source
  // the arc length is either zero (to make calibers zero)
  // or large

  for (i = 2; i < n; i++) {
    v = n;
    w = i;
    printf("a %ld %ld %lld\n", ID(v), ID(w), caliber*(deltaL - (long long) 1));
  }

  // finally, a small arc
  v = n;
  w = 1;
  printf("a %ld %ld 0\n", ID(v), ID(w));

  // all is done
  exit (0);

  /* ----- wrong usage ----- */
 usage:
  fprintf ( stderr,
"\nUSAGE: %s N D L C seed \nwhere N is the number of nodes (may be truncated)\nD is log(delta)\nL is the number of levels\nC is a 0/1 caliber multiplier\nseed is a pseudorandom generator seed\n",
	   argv[0]);
 exit (4);
}
