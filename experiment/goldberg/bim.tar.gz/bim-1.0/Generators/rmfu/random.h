void SetRandom(long seed);
long Random(long a, long b);
double DblUnitRandom();
void RandomPermute(long rgi[], long iMac);

