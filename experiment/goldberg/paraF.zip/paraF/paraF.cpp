//(C) Microsoft Corporation. All rights reserved.
#include "stdafx.h"
#include "Parser.h"
#include "Solver.h"
#include "Utils.h"

using namespace paraF;

int main(int argc, char** argv)
{
	Graph graph;
	InputParser parser;
	Problem problem;
	Solver solver;
		
	try
	{
		int i = 1;

		bool hasLambdaRange = false;
		bool solveMaxFlowForMaxBreakpoint;
		int minLambda;
		int maxLambda;

		while (i < argc)
		{
			if (strcmp(argv[i], "--input") == 0)
			{
				i++;
				if (i >= argc)
					throw "input filename expected";
				if (!freopen(argv[i], "r", stdin))
					throw "failed to open input file";
				i++;
			}
			else if (strcmp(argv[i], "--st-only") == 0)
			{
				solver.mode = Solver::GGT_ST_ONLY_ALGORITHM;
				i++;
			}
			else if (strcmp(argv[i], "--ts-only") == 0)
			{
				solver.mode = Solver::GGT_TS_ONLY_ALGORITHM;
				i++;
			}
			else if (strcmp(argv[i], "--both") == 0)
			{
				solver.mode = Solver::GGT_BOTH_ALGORITHM;
				i++;
			}
			else if (strcmp(argv[i], "--simple") == 0)
			{
				solver.mode = Solver::SIMPLE_ALGORITHM;
				i++;
			}
			else if (strcmp(argv[i], "--print-cuts") == 0)
			{
				solver.printCuts = true;
				i++;
			}
			else if (strcmp(argv[i], "--debug-verbosity") == 0)
			{
				solver.verbosity = Solver::DEBUG_VERBOSITY;
				i++;
			}
			else if (strcmp(argv[i], "--normal-verbosity") == 0)
			{
				solver.verbosity = Solver::NORMAL_VERBOSITY;
				i++;
			}
			else if (strcmp(argv[i], "--quiet-verbosity") == 0)
			{
				solver.verbosity = Solver::QUIET_VERBOSITY;
				i++;
			}
			else if (strcmp(argv[i], "--range") == 0)
			{
				i++;
				hasLambdaRange = true;
				if (i >= argc)
					throw "min lambda expected";
				minLambda = atoi(argv[i]);
				i++;
				if (i >= argc)
					throw "max lambda expected";
				maxLambda = atoi(argv[i]);
				i++;
			}
			else if (strcmp(argv[i], "--max-bp-only") == 0)
			{
				solver.maxBreakpointOnly = true;
				i++;
			}
			else if (strcmp(argv[i], "--solve-max-flow-for-max-bp") == 0)
			{
				solveMaxFlowForMaxBreakpoint = true;
				i++;
			}
			else
				throw "unrecognized command line option";
		}

		int time0 = GetTime();

		parser.Parse(graph, problem);
		if (hasLambdaRange)
		{
			problem.hasLambdaRange = true;
			problem.minLambda = minLambda;
			problem.maxLambda = maxLambda;
		}

		printf("c Nodes: %d\n", graph.nodes.size());
		printf("c Arcs: %d\n", graph.arcs.size());

		int time1 = GetTime();
		printf("c Parse time: %d\n", time1 - time0);
		printf("c\n");

		switch (problem.type)
		{
		case Problem::MAX_FLOW_PROBLEM:
			{
				graph.InitPreflowPush(0);
				graph.FindMaxPreflow();
				graph.PrintStats("st");
				printf("c Max flow value is %" LONGTYPE_SPEC "\n", graph.GetSinkNode()->excess);

				int time2 = GetTime();
				printf("c Forward solve time: %d\n", time2 - time1);

				int time3 = GetTime();
				graph.ConvertPreflowToFlow();
				int time4 = GetTime();
				printf("c Forward preflow-to-flow time: %d\n", time4 - time3);
				printf("c\n");

				Graph revGraph;
				graph.Reverse(revGraph);

				int time5 = GetTime();
				revGraph.InitPreflowPush(0);
				revGraph.FindMaxPreflow();
				revGraph.PrintStats("ts");
				printf("c Max flow value is %" LONGTYPE_SPEC "\n", graph.GetSinkNode()->excess);
				int time6 = GetTime();
				printf("c Backward solve time: %d\n", time6 - time5);

				int time7 = GetTime();
				revGraph.ConvertPreflowToFlow();
				int time8 = GetTime();
				printf("c Backward preflow-to-flow time: %d\n", time8 - time7);

				break;
			}

		case Problem::PARAMETRIC_FLOW_PROBLEM:
			{
				solver.Solve(graph, problem);
				int time2 = GetTime();
				printf("c Solve time: %d\n", time2 - time1);

				if (solveMaxFlowForMaxBreakpoint)
				{
					int time0 = GetTime();
					graph.ClearStats();
					graph.InitPreflowPush(solver.maxBreakpoint);
					graph.FindMaxPreflow();
					graph.ConvertPreflowToFlow();
					int time1 = GetTime();
					printf("c\n");
					printf("c Max-flow for max-breakpoint time: %d\n", time1 - time0);
					graph.PrintStats("max-bp");
				}

				break;
			}
		}

	}
	catch (const char* msg)
	{
		printf("ERROR: %s\n", msg);
		return 1;
	}
}

