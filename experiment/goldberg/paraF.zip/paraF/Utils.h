//(C) Microsoft corporation. All rights reserved
#ifndef Utils_h_SEEN
#define Utils_h_SEEN

namespace paraF
{

LongType abs(LongType value);
LongType gcd(LongType a, LongType b);
int GetTime();

}

#endif
